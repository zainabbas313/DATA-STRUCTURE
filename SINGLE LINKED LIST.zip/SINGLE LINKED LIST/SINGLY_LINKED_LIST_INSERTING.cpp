#include<iostream>
//add a node at the of the linked list 
using namespace std;
class node
{
	 public:
	 	int data;
	 	node *link;
};
//EITHER USE DOUBLE POINTER OR RETURN THE UPDATED ADDRESS OF HEAD
void add_at_end(node **head)
{
	if(*head == NULL)
	{
		node *temp = new node;
		cout<<"ENTER : ";
		cin>>temp->data;
		temp->link = NULL;
		*head = temp;
	}
	else
	{
		node *temp = new node, *ptr;
		ptr = *head;
		cout<<"ENTER : ";
		cin>>temp->data;
		temp->link = NULL;
		while(ptr->link != NULL)
		{
			ptr = ptr->link;
		}
		ptr->link = temp;
	}
}
/*
//THIS ON IS ALSO CORRECT BUT WE HAVE TO RETURN THE HEAD UPDATA ADDRESS
node *add_at_beg(node *head)
{
	node *temp = new node;
	temp->link = NULL;
	temp->link = head;
	cout<<"ENTER : ";
	cin>>temp->data;
	head = temp;
	return head;
}*/
void add_at_beg(node **head)
{
	node *temp = new node;
	temp->link = NULL;
	temp->link = *head;
	cout<<"ENTER : ";
	cin>>temp->data;
	*head = temp;
}
void print_elements(node *head)
	{
		int count = 0;
		if(head == NULL)
		{
			cout<<"LINKED LIST IS EMPTY"<<endl;	
		}
		node *current = new node;
		current = head;
		while( current != NULL)
		{
			cout<<current->data<<" ";
			current = current->link;	
		}
		
}
int main()
{
	node *head = new node;
	head->data = 45;
	head->link = NULL;
	cout<<"HEAD ADDRESS (some address) : "<<head<<endl
		<<"HEAD LINK STORED ADDRESS (null) : "<<head->link<<endl<<endl;
	
	node *curr = new node;
	curr->data = 89;
	curr->link = NULL;
	head->link = curr;
	cout<<"CURR ADDRESS (some address) : "<<curr<<endl
		<<"CURR LINK STORED ADDRESS (null) : "<<curr->link<<endl
		<<"HEAD LINK STORED ADDRESS (curr address "<<curr <<") : "<<head->link<<endl<<endl;
		
	void *x = curr;
	curr = new node;
	curr->data = 9;
	curr->link = NULL;
	head->link->link = curr;
	cout<<"CURR ADDRESS (some new address not that address "<<x<<") : "<<curr<<endl
		<<"CURR LINK STORED ADDRESS (null) : "<<curr->link<<endl
		<<"HEAD LINK STORED ADDRESS (curr1 address "<<x<<") : "<<head->link<<endl
		<<"HEAD LINK link STORED ADDRESS (curr address "<<curr <<") : "<<head->link->link<<endl
		<<"HEAD LINK link link STORED NULL "<<head->link->link->link<<endl;
		
	cout<<head->link<<" "<<head->link->link<<" "<<head->link->link->link<<endl<<endl;
	
	void *y = curr;
	curr = new node;
	curr->data = 90;
	curr->link = NULL;
	head->link->link->link = curr;
	cout<<"CURR ADDRESS (some new address not that address "<<x<<") : "<<curr<<endl
		<<"CURR LINK STORED ADDRESS (null) : "<<curr->link<<endl
		<<"HEAD LINK STORED ADDRESS (curr1 address "<<x<<") : "<<head->link<<endl
		<<"HEAD LINK link STORED ADDRESS (curr address "<<y<<") : "<<head->link->link<<endl
		<<"HEAD LINK link link STORED "<<curr<<" "<<head->link->link->link<<endl;
		
	cout<<head->link<<" "<<head->link->link<<" "<<head->link->link->link<<" "<<head->link->link->link->link<<endl;
	node *head1 = new node;
	head1 = NULL;
 	add_at_end(&head1);
	add_at_end(&head1);
	add_at_end(&head1);
	add_at_end(&head1);	
	add_at_beg(&head1);
	add_at_beg(&head1);

	cout<<"THE DATA OF LINKED LIST : ";
	print_elements(head1);
	return 0;
}

