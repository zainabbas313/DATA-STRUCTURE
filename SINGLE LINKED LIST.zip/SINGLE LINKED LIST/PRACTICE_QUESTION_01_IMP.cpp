/*Write a program that prompts the users to enter 12 numbers. This program reads the numbers into a  linked list. Make another Linked list that will store the average of numbers.
The two lists will be passed to a function for and the average will be calculated by
a.	Take First Four nodes of "numbers list" calculate their average and store at first node  in "Average linked list".
b.	Next time skip the first node of "numbers list" and average the next 4 nodes and store at second node in Average linked list.
c.	And this procedure will continue, until Average for all will be stored in Averagelist.
*/
#include<iostream>
using namespace std;

class node
{
    public:
        int data;
        int key;
        node * next;
        node()
        {
            next = NULL;
        }
        node(int data, int key)
        {
            this->data = data;
            this->key = key;
            next = NULL;
        }
        ~node()
        {
            delete next;
        }
};
class sllnode
{
    public:
        node*head;
        node*tail;
        sllnode()
        {
            head = NULL;
            tail = NULL;
        }
        sllnode(int val, int k)
        {
            node*ptr  = new node;
            head = tail = ptr;
            ptr->next = NULL;
            ptr->data = val;
            ptr->key = k;
        }
        void insert_at_end(int val,int k)
        {
            node*ptr = new node;
                if(head == NULL)
                {
                    head = ptr;
                    ptr->next = NULL;
                    ptr->data = val;
                    ptr->key = k;
                }
                else
                {
                    node* temp = head;
                    while(temp->next != NULL)
                    {
                        temp = temp->next;
                    }
                    temp->next = ptr;
                    ptr->next = NULL;
                    ptr->data = val;
                    ptr->key = k;
                    tail = ptr;
                }
        }
        void insert_at_beg(int val,int k)
        {
            node* ptr = new node;
            if(head == NULL)
            {
                head = tail = ptr;
                ptr->data = val;
                ptr->key = k;
                ptr->next = NULL;
            }
            else
            {
                node*temp = head;
                head = ptr;
                ptr->next = temp;
                ptr->data = val;
                ptr->key = k;
            }
        }
        void delete_of_end()
        {
            if(head == NULL)
            {
                cout<<"LIST DOES NOT EXCIT"<<endl;
            }
            else
            {
                node*temp = head;
                node*prev = head;
                while(temp->next != NULL)
                {
                    prev = temp;
                    temp = temp->next;
                }
                prev->next = NULL;
                delete temp;
            }
        }
        
        void print()
        {
            node*temp = head;
            while(temp != NULL)
            {
                cout<<"data : "<<temp->data<<" "<<"key : "<<temp->key<<endl;
                temp = temp->next;
            }
        }
        
        friend void functi0n(sllnode &list,sllnode &avg_num,int size);
};

void function(sllnode &list,sllnode &avg_num,int size)
        {
            node* temp1 = list.head;
            node* temp2 = avg_num.head;
            int sum = 0;
            int x = 0;
            while(x != size)
            {
                temp1 = temp1->next;
                x++;
            }
            for(int i = size ;i < size+4; i++)
            {
             	sum = sum + temp1->data;
				temp1= temp1->next;
				if(temp1 == NULL)
				{
					break;	
				}   
            }
			avg_num.insert_at_end(sum/4,size);
        }

int main()
{
    sllnode list(10,0);
    sllnode avg_num;
    list.insert_at_end(20,1);
    list.insert_at_end(30,2);
    list.insert_at_end(40,3);
    list.insert_at_end(50,4);
    list.insert_at_end(60,1);
    list.insert_at_end(70,2);
    list.insert_at_end(80,3);
    list.insert_at_end(90,4);
    list.insert_at_end(20,1);
    list.insert_at_end(30,2);
    list.insert_at_end(40,3);
    list.insert_at_end(50,4);
    	for(int i = 0 ; i < 9 ;i++)
    	{
    		function(list,avg_num,i);
		}
	cout<<"THE GIVEN LIST"<<endl;	
	list.print();
	cout<<"THE AVERAGE OF THE FIRST 4 SEQUENCES OF LIST"<<endl;
	avg_num.print();
 
    
    return 0;
}


