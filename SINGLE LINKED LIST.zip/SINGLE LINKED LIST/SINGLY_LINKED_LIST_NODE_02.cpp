#include<iostream>
#include<cstdlib>
using namespace std;
class node
{
	public:
		int data;
		node *link;
};
int main()
{
	node *head = new node;
	head->data = 45;
	head->link = NULL;
	cout<<"HEAD ADDRESS (some address) : "<<head<<endl
		<<"HEAD LINK STORED ADDRESS (null) : "<<head->link<<endl<<endl;
	
	node *curr = new node;
	curr->data = 89;
	curr->link = NULL;
	head->link = curr;
	cout<<"CURR ADDRESS (some address) : "<<curr<<endl
		<<"CURR LINK STORED ADDRESS (null) : "<<curr->link<<endl
		<<"HEAD LINK STORED ADDRESS (curr address "<<curr <<") : "<<head->link<<endl<<endl;
	
	node *curr1 = new node;
	curr1->data = 9;
	curr1->link = NULL;
	curr->link = curr1;
	cout<<"CURR1 ADDRESS (some address) : "<<curr1<<endl
		<<"CURR1 LINK STORED ADDRESS (null) : "<<curr1->link<<endl
		<<"CURR LINK STORED ADDRESS (curr1 address "<<curr1 <<") : "<<curr->link<<endl
		<<"HEAD LINK STORED ADDRESS (curr address "<<curr <<") : "<<head->link<<endl<<endl;
		
	cout<<head->link<<" "<<head->link->link<<" "<<head->link->link->link<<endl;
	
	
	
	return 0;
}

