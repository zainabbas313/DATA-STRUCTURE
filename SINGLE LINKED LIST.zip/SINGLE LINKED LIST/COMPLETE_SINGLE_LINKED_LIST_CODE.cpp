#include<iostream>
using namespace std;
class sllnode
{
	public:
		int info;
		sllnode* link;
		sllnode* head;
	
		sllnode()
		{
			link = NULL;
			head = NULL;
		}
		sllnode(int data, sllnode* ptr = NULL)
		{
			info = data;
			link = NULL;
			head = NULL;
		}
		//inserting the node
		void insert_at_the_end(sllnode* head,int value)
		{
			sllnode* node = new sllnode;
			node->info = value;
			node->link = NULL;
				while(head->link != NULL)
				{
					head= head->link;
				}
				head->link = node;
		}
		
		void insert_at_the_beg(sllnode *head,int value)
		{
			sllnode* node = new sllnode;
			node->info = value;
			if(head == NULL)
			{
				head->link = node;
				node->link = NULL;
			}
			else
			{
				node->link = head;
			}
		}
		
		void insert_at_i(sllnode *head,int value, int location)
		{
			sllnode* node = new sllnode,*next;
			node->info = value;
			for(int i = 0; i < location; i++)
			{
				head = head->link;
			}
			node->link = head->link;
			head->link = node;
		}
		
		//get the values
		void get_value(sllnode *head)
		{
		    if(head == NULL)
			{
			    cout<<head->info<<endl;
			}
			while(head != NULL)
			{
				cout<<head->info<<" ";
				head = head->link;
			}
		}
};
int main()
{
	sllnode *head = new sllnode(10);
	head->get_value(head);
	head->link = new sllnode(20);
	head->get_value(head);
	head->insert_at_i(head,30,1);
	head->get_value(head);
	cout<<endl;
	head->insert_at_the_end(head,50);
	head->get_value(head);
	return 0;
}

