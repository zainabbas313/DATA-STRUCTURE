#include<iostream>
#include<cstdlib>
using namespace std;
//the class_node is basically a node of a linked list
//either we have to make a struct named as node or create a class named as node 
// in which node elements (data and the link) always be public encapsulated 
class node
{
	public:
	int data;
	node *link; 
};


class linked : public node
{
	private:
		node *head = NULL;
	public:
		linked()
		{
			//both will work same
//			head = (struct node*)malloc(sizeof(struct node));
			head = new node;
		}
		void set()
		{
			cout<<"ENTER A DATA : ";
			cin>>head->data;
			head->link = NULL;
		}
		void get()
		{
			cout<<"DATA : "<<head->data<<endl;
		}
			
};
int main()
{
	linked a;
	a.set();
	a.get();

	return 0;
}

