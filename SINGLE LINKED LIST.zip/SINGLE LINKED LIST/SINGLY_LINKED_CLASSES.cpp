#include<iostream>
using namespace std;
class node
{	 
	public:
		int data;
		node *next;
		node()
		{
			next = NULL;
		}
		node(int data)
		{
			this->data = data;
			next = new node;
		}
};
class singly
{
	public:
		node *head;
		singly()
		{
			head = NULL;	
		}
		singly(int dat)
		{
			node *ptr = new node;
			head->next = ptr;
			ptr->data = dat;
			ptr->next = NULL;
		}
		void insert_at_end(int data)
		{
			node* temp;
			temp = head;
			while(temp->next != NULL)
			{
				temp = temp->next;
			}
			node *new_node = new node;
			new_node->next = NULL;
			temp->next = new_node;
			new_node->data = data;
		}
		void print()
		{
			node* temp;
			temp = head;
			while(temp->next != NULL)
			{
				cout<<temp->data<<" ";
				temp = temp->next;
			}
		}
};
int main()
{
	singly p(10);
	p.print();
	return 0;
}

