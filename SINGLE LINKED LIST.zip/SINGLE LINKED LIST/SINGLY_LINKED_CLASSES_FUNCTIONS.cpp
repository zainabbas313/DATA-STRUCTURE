#include<iostream>
using namespace std;
class node
{
    public:
        int data;
        int key;
        node * next;
        node()
        {
            next = NULL;
        }
        node(int data, int key)
        {
            this->data = data;
            this->key = key;
            next = NULL;
        }
        ~node()
        {
            delete next;
        }
};
class sllnode
{
    public:
        node*head;
        node*tail;
        sllnode()
        {
            head = NULL;
            tail = NULL;
        }
        sllnode(int val, int k)
        {
            node*ptr  = new node;
            head = tail = ptr;
            ptr->next = NULL;
            ptr->data = val;
            ptr->key = k;
        }
        void insert_at_end(int val,int k)
        {
            node*ptr = new node;
                if(head == NULL)
                {
                    head = ptr;
                    ptr->next = NULL;
                    ptr->data = val;
                    ptr->key = k;
                }
                else
                {
                    node* temp = head;
                    while(temp->next != NULL)
                    {
                        temp = temp->next;
                    }
                    temp->next = ptr;
                    ptr->next = NULL;
                    ptr->data = val;
                    ptr->key = k;
                    tail = ptr;
                }
        }
        void insert_at_beg(int val,int k)
        {
            node* ptr = new node;
            if(head == NULL)
            {
                head = tail = ptr;
                ptr->data = val;
                ptr->key = k;
                ptr->next = NULL;
            }
            else
            {
                node*temp = head;
                head = ptr;
                ptr->next = temp;
                ptr->data = val;
                ptr->key = k;
            }
        }
        void delete_of_end()
        {
            if(head == NULL)
            {
                cout<<"LIST DOES NOT EXCIT"<<endl;
            }
            else
            {
                node*temp = head;
                node*prev = head;
                while(temp->next != NULL)
                {
                    prev = temp;
                    temp = temp->next;
                }
                prev->next = NULL;
                delete temp;
            }
        }
        friend int count_node(sllnode *list);
        void print()
        {
            node*temp = head;
            while(temp != NULL)
            {
                cout<<"data : "<<temp->data<<" "<<"key : "<<temp->key<<endl;
                temp = temp->next;
            }
        }
};
int count_node(sllnode *list)
        {
        	node * temp = list->head;
        	int count = 0;
        	while(temp != NULL)
        	{
        		temp = temp->next;
        		count++;
			}
			return count;
		}
int main()
{
    sllnode list(10,1);
    list.insert_at_end(33,5);
    list.insert_at_end(99,6);
    list.insert_at_beg(19,3);
    list.insert_at_beg(19,3);
    list.print();
    	if(count_node(&list)%2 == 0)
    	{
    		cout<<"LINKED LIST HAVE EVEN NUMBERS OF NODE."<<endl;
		}
		else
		{
			cout<<"LINKED LIST HAVE ODD NUMBERS OF NODE."<<endl;
		}
    
    return 0;
}


