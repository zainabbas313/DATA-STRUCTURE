#include<iostream>
using namespace std;
class node
{
	 public:
	 	int data;
	 	node *link;
};
void count_elements(node *head)
	{
		int count = 0;
		if(head == NULL)
		{
			cout<<"LINKED LIST IS EMPTY"<<endl;	
		}
		node *current = new node;
		current = head;
		while( current != NULL)
		{
			count++;
			current = current->link;	
		}
		cout<<"NUMBER OF NODES IN LINKED LIST : "<<count<<endl;	
}
int main()
{
	node *head = new node;
	head->data = 45;
	head->link = NULL;
	cout<<"HEAD ADDRESS (some address) : "<<head<<endl
		<<"HEAD LINK STORED ADDRESS (null) : "<<head->link<<endl<<endl;
	
	node *curr = new node;
	curr->data = 89;
	curr->link = NULL;
	head->link = curr;
	cout<<"CURR ADDRESS (some address) : "<<curr<<endl
		<<"CURR LINK STORED ADDRESS (null) : "<<curr->link<<endl
		<<"HEAD LINK STORED ADDRESS (curr address "<<curr <<") : "<<head->link<<endl<<endl;
		
	void *x = curr;
	curr = new node;
	curr->data = 9;
	curr->link = NULL;
	head->link->link = curr;
	cout<<"CURR ADDRESS (some new address not that address "<<x<<") : "<<curr<<endl
		<<"CURR LINK STORED ADDRESS (null) : "<<curr->link<<endl
		<<"HEAD LINK STORED ADDRESS (curr1 address "<<x<<") : "<<head->link<<endl
		<<"HEAD LINK link STORED ADDRESS (curr address "<<curr <<") : "<<head->link->link<<endl
		<<"HEAD LINK link link STORED NULL "<<head->link->link->link<<endl;
		
	cout<<head->link<<" "<<head->link->link<<" "<<head->link->link->link<<endl<<endl;
	
	void *y = curr;
	curr = new node;
	curr->data = 90;
	curr->link = NULL;
	head->link->link->link = curr;
	cout<<"CURR ADDRESS (some new address not that address "<<x<<") : "<<curr<<endl
		<<"CURR LINK STORED ADDRESS (null) : "<<curr->link<<endl
		<<"HEAD LINK STORED ADDRESS (curr1 address "<<x<<") : "<<head->link<<endl
		<<"HEAD LINK link STORED ADDRESS (curr address "<<y<<") : "<<head->link->link<<endl
		<<"HEAD LINK link link STORED "<<curr<<" "<<head->link->link->link<<endl;
		
	cout<<head->link<<" "<<head->link->link<<" "<<head->link->link->link<<" "<<head->link->link->link->link<<endl;
	count_elements(head);
	return 0;
}

