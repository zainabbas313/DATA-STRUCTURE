#include<iostream>
using namespace std;

class node
{
    public:
        int data;
        int key;
        node * next;
        node * prev;
        node()
        {
            next = prev = NULL;
        }
        node(int data, int key)
        {
            this->data = data;
            this->key = key;
            next = prev = NULL;
        }
        ~node()
        {
            delete next;
        }
};
class c_dllnode
{
    public:
        node * head;
        node * tail;
        c_dllnode()
        {
            head = tail = NULL;
        }
        c_dllnode(int val, int k)
        {
            node * ptr  = new node;
            head = tail = ptr;
            ptr->next = head;
            ptr->prev = tail;
            ptr->data = val;
            ptr->key = k;
        }
        void insert_at_end(int val,int k)
        {
            node * ptr = new node;
            node * temp = head;
                while(temp->next != head)
                {
                    temp = temp->next;
                }
                temp->next = ptr;
                ptr->prev = temp;
                ptr->next = head;
                tail =  ptr;
                ptr->data = val;
                ptr->key = k;
        }
        void insert_at_beg(int val,int k)
        {
            node* ptr = new node;
            ptr->data = val;
            ptr->key = k;
            node*temp = head;
                while(temp->next != head)
                {
                    temp = temp->next;
                }
                temp->next = ptr;
                ptr->next = head;
                temp = temp->next;
                temp->prev = ptr;
                head = ptr;
        }
        void delete_of_end()
        {
            node*temp = head;
            node*prev = head;
            while(temp->next != head)
            {
                prev = temp;
                temp = temp->next;
            }
            prev->next = temp->next;
            tail = prev;
        }
        
        void delete_by_key(int k)
        {
            node * temp = head;
            node * before_temp = head;
            int flag = 0;
            while(temp->key != k)
            {
                before_temp = temp;
                temp = temp->next;
                if(temp == head)
                {
                    flag++;
                }
            }
            if(flag == 0)
            {
                before_temp->next = temp->next;
                node* temp2 = temp;
                temp = temp->next;
                temp->prev = before_temp;
            }
            else
            {
                cout<<"THIS KEY NODE DOES NOT EXIST"<<endl;
            }
        }
        
        
        void print_by_head()
        {
            node * temp = head;
            node * temp1 = head->next;
            if(head == head->next)
            {
                cout<<"NO LIST FOUND"<<endl;
            }
            while(temp != temp1)
            {
                temp1 = head;
                cout<<"data : "<<temp->data<<" "<<"key : "<<temp->key<<endl;
                temp = temp->next;
            }
        }
        
};

int main()
{
    c_dllnode list(10,0);
    list.insert_at_end(20,1);
    list.insert_at_end(30,2);
    list.insert_at_end(40,4);
    list.insert_at_beg(50,5);
    list.delete_of_end();
    list.delete_by_key(2);
    list.delete_by_key(5);
    list.delete_by_key(0);
    list.delete_by_key(1);
    list.print_by_head();
    list.insert_at_end(20,1);
    list.insert_at_end(30,2);
    list.insert_at_end(40,4);
    list.insert_at_beg(50,5);
    list.print_by_head();
 
    
    return 0;
}


