#include<iostream>
using namespace std;

class node
{
    public:
        int data;
        int key;
        node * next;
        node()
        {
            next = NULL;
        }
        node(int data, int key)
        {
            this->data = data;
            this->key = key;
            next = NULL;
        }
        ~node()
        {
            delete next;
        }
};
class cllnode
{
    public:
        node*head;
        cllnode()
        {
            head = NULL;
        }
        cllnode(int val, int k)
        {
            node*ptr  = new node;
            head = ptr;
            ptr->next = head;
            ptr->data = val;
            ptr->key = k;
        }
        void insert_at_end(int val,int k)
        {
            node * ptr = new node;
            node * temp = head;
                while(temp->next != head)
                {
                    temp = temp->next;
                }
                temp->next = ptr;
                ptr->next = head;
                ptr->data = val;
                ptr->key = k;
        }
        void insert_at_beg(int val,int k)
        {
            node* ptr = new node;
            ptr->data = val;
            ptr->key = k;
            node*temp = head;
            if(head == head->next)
            {
            	ptr->next = head;
            	head = ptr;
            	ptr->data = val;
            	ptr->key = k;
            	return;
			}
                while(temp->next != head)
                {
                    temp = temp->next;
                }
                temp->next = ptr;
                ptr->next = head;
                head = ptr;
        }
        void delete_of_end()
        {
            node*temp = head;
            if(temp == temp->next)
            {
                head = NULL;
                delete temp;
                temp = NULL;
                return;
            }
            node*prev = head;
            while(temp->next != head)
            {
                prev = temp;
                temp = temp->next;
            }
            prev->next = head;
            temp->next = NULL;
            delete temp;
            temp = NULL;
        }
        
        void print()
        {
            node * temp = head;
            node * temp1 = head->next;
            if(head == NULL)
            {
                cout<<"LIST DOES NOT FOUND"<<endl;
                return;
            }
            if(head ==  head->next)
            {
                cout<<"data : "<<head->data<<" "<<"key : "<<head->key<<endl;
            }
            while(temp != temp1)
            {
                temp1 = head;
                cout<<"data : "<<temp->data<<" "<<"key : "<<temp->key<<endl;
                temp = temp->next;
            }
        }
};

int main()
{
    cllnode list(10,0);
    list.insert_at_end(20,1);
    list.insert_at_end(30,2);
    list.insert_at_end(40,4);
    list.insert_at_beg(50,5);
    list.delete_of_end();
    list.delete_of_end();
    list.delete_of_end();
    list.delete_of_end();
    list.delete_of_end();
    list.print();
 
    
    return 0;
}


