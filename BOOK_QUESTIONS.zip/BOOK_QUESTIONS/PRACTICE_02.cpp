#include<iostream>
using namespace std;

int main()
{
	int arr[6]= {6,3,5,9,2,8};
	int i = -1,j = 0, p =arr[5];
	for(int  i = -1 ; i < 5 ; )
	{
	for(int j = 0 ; j < 6; j++)
	{
		if(arr[j] < p)
		{
			i++;
			int temp = arr[j];
			arr[j] = arr[i];
			arr[i] = temp;
		}
	}
	i++;
	int temp = arr[i];
	arr[i]= p;
	arr[5] = temp;
	}
		
	for(int i = 0 ; i < 6 ; i++)
	{
		cout<<arr[i]<<" ";
	}

	return 0;
}

