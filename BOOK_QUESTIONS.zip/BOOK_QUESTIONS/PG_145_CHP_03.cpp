#include<iostream>
using namespace std;
class node
{
    public:
        int data;
        int num;
        int den;
        node * next;
        node()
        {
            next = NULL;
        }
        node(int data, int num,int den)
        {
            this->data = data;
            this->num = num;
            this->den = den;
            next = NULL;
        }
        ~node()
        {
            delete next;
        }
};
class sllnode
{
    public:
        node*head;
        node*tail;
        sllnode()
        {
            head = NULL;
            tail = NULL;
        }
        void first_n_last_node()
        {
        	node * ptr = new node;
        	node * ptr1 = new node;
        	head = ptr;
        	ptr->num = 0;
        	ptr->den = 1;
        	tail = ptr1;
        	ptr1->num = 1;
        	ptr1->den = 1;
        	ptr->next = ptr1;
        	ptr1->next = NULL;
		}
        void insert_at_level(int level)
        {
        	if(level == 1)
        	{
        		first_n_last_node();
			}
			else
			{
				node * temp = head;
				node *temp1 = head;
				node* hold = head;
				for(int  i = 2 ; i <= level ; i++ )
				{
					if(i == 2)
					{
						node * temp = head;
						node *temp1 = tail;
							node * ptr = new node;
							ptr->num = temp->num + temp1->num;	
							ptr->den = temp->den + temp1->den;
							temp->next = ptr;
							ptr->next = tail;				
					}
					else
					{
						temp = temp1 = head;
						node * ptr1 = new node;
						ptr1->num = temp->num + temp->next->num;	
						ptr1->den = temp->den + temp->next->den;
						ptr1->next = temp->next;
						temp->next = ptr1;
						while(temp1->next->next != NULL)
						{
							temp1 = temp1->next;
						}
						hold = temp1;
						node * ptr2 = new node;
						ptr2->num = temp1->num + temp1->next->num;
						ptr2->den = temp1->den + temp1->next->den;
						ptr2->next = temp1->next;
						temp1->next = ptr2;						
					}
				}
			}           
        }
        void print()
        {
            node * temp = head;
            while(temp != NULL)
            {
            	cout<<temp->num <<"/"<<temp->den<< " , ";
                temp = temp->next;
            }
        }
};
int main()
{
    sllnode list;
    list.first_n_last_node();
    list.insert_at_level(10);
    list.print();
    
    return 0;
}

/* Farey fractions of level one are defined as sequence 1 0
1, 1
1 2. This sequence is extended 
in level two to form a sequence 1
0
1, 1
2, 1
1 2, sequence 1
0
1, 1
3, 1
2, 2
3, 1
1 2 at level three, sequence 
1
0
1, 1
4, 1
3, 1
2, 2
3, 3
4, 1
1 2 at level four, so that at each level n, a new fraction a1b
c1d is inserted 
between two neighbor fractions a
c and b
d only if c + d = n. Write a program that for a 
number n entered by the user creates�by constantly extending it�a linked list of 
fractions at level n and then displays them.*/
