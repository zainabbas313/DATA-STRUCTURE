#include<iostream>
using namespace std;
void merge(int *arr,int l,int mid,int r)
{
	int x = mid - l + 1;
	int y = r - mid;
	int a[x],b[y];
	for(int i = 0 ; i < x;i++)
	{
		a[i] = arr[l+i];
	}
	for(int i = 0; i < y;i++)
	{
		b[i] = arr[mid+1+i];
	}
	int  i = 0 , k = l , j = 0 ;
	while(x != i && y != j)
	{
		if(a[i]>b[j])
		{
			arr[k] = b[j];
			j++;k++;
		}
		else
		{
			arr[k] = a[i];
			i++;k++;
		}
	}
	while(x > i)
	{
		arr[k] = a[i];
		i++;k++;
	}
	while(y > j)
	{
		arr[k] = b[j];
		j++;k++;
	}
}
void merge_sort(int *arr,int l,int r)
{
	if(l<r)
	{
		int mid = (l+r)/2;
		merge_sort(arr,l,mid);
		merge_sort(arr,mid+1,r);
		merge(arr,l,mid,r);	
	}	
}
int main()
{
	int arr[10];
	int *p = arr;
	cout<<"ENTER THE 10 NUMBERS IN ARRAY : ";
	for(int i = 0 ; i < 10; i++)
	{
		cin>>arr[i];
	}
	cout<<"NUMBERS ARE : ";
	for(int i = 0 ; i < 10; i++)
	{
		cout<<arr[i]<<" ";
	}
	merge_sort(arr,0,9);
	cout<<endl<<"SORTED ARRAY NUMBERS ARE : ";
	for(int i = 0 ; i < 10; i++)
	{
		cout<<arr[i]<<" ";
	}
	delete p;
	return 0;
}











