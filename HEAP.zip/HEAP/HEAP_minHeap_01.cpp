#include<iostream>
using namespace std;
class MinHeap
{
	public:
		int *heap_array;
		int capacity;
		int heap_size;
		Minheap()
		{
			capacity = 0;
			heap_array = NULL;
		}	
		MinHeap(int capacity)
		{
			heap_size = 0;
			this->capacity = capacity;
			heap_array = new int[capacity];	
		}
		void insert(int val)
		{
			if(heap_size == capacity)
			{
				cout<<"HEAP OVERFLOW"<<endl;
				return;
			}
			heap_size++;
			int i = heap_size-1;
			heap_array[i] = val;
			while(i != 0 && heap_array[parent(i)] > heap_array[i])
			{
				swap(&heap_array[parent(i)],&heap_array[i]);
				i = parent(i);
			}
		}
		void heapify_down(int i)
		{
			int l = left_child(i);
			int r = right_child(i);
			int smallest = i;
			if(heap_size > l && heap_size > r)
			{
				if(heap_array[l] > heap_array[r])
				{
					smallest = r;
				}
				else
				{
					smallest = l;
				}
			}
					
			if(smallest != i && heap_array[i] > heap_array[smallest])
			{
				swap(&heap_array[i],&heap_array[smallest]);
				heapify_down(smallest);
			}
		}
		void swap(int* x,int* y)
		{
			int temp = *x;
			*x = *y;
			*y = temp;
		}
		int parent(int index)
		{
			return (index-1)/2;
		}
		int left_child(int index)
		{
			return(2*index + 1);
		}
		int right_child(int index)
		{
			return(2*index + 2);
		}
		void print()
		{
			for(int  i = 0 ; i < heap_size;i++)
			{
				cout<<heap_array[i]<<" ";	
			}	
			cout<<endl<<endl;
		} 
		void delete_node(int val)
		{
			int i = 0;
			for(i = 0; i < heap_size;i++)
			{
				if(heap_array[i] == val)
				{
					heap_array[i] = heap_array[0] - 1;
					break;
				}
			}
			swap(&heap_array[i],&heap_array[heap_size-1]);
			heap_size--;
			heapify_down(i);
		}
};
int main()
{
	MinHeap bin(10);
	bin.insert(2);
	bin.insert(4);
	bin.insert(6);
	bin.insert(3);
	bin.insert(7);
	bin.insert(9);
	bin.insert(1);
	bin.insert(12);
	bin.insert(13);
	bin.insert(14);
	bin.print();
	bin.delete_node(1);
	bin.delete_node(9);
	bin.print();
	return 0;
}

