#include<iostream>
using namespace std;
class MaxHeap
{
	public:
		int* heap_array;
		int capacity;
		int heap_size;
		MaxHeap()
		{
			heap_array= NULL;
			heap_size = 0;
		}
		MaxHeap(int capacity)
		{
			heap_array = new int[capacity];
			this->capacity = capacity;
			heap_size = 0;	
		}
		void insert(int val)
		{
			if(heap_size == capacity)
			{
				cout<<"HEAP OVERFLOW!!"<<endl;
				return;
			}
			heap_size++;
			int i = heap_size-1;
			heap_array[i] = val;
			while(i != 0 && heap_array[i] > heap_array[parent(i)])
			{
				swap(&heap_array[i],&heap_array[parent(i)]);
				i = parent(i);
			}
		}
		void heapify_up(int i)
		{
			int l = left_child(i);
			int r = right_child(i);
			int largest = i;
			if(heap_size > l && heap_size > r)
			{
				if(heap_array[l] > heap_array[r])
				{
					largest = l;
				}
				else
				{
					largest = r;
				}
			}
					
			if(largest != i && heap_array[i] < heap_array[largest])
			{
				swap(&heap_array[i],&heap_array[largest]);
				heapify_up(largest);
			}
		}
		int left_child(int index)
		{
			return (2*index + 1);
		}
		int right_child(int index)
		{
			return (2*index + 2);
		}
		void swap(int* x,int* y)
		{
			int temp = *x;
			*x = *y;
			*y = temp;
		}
		int parent(int index)
		{
			return (index-1)/2;
		}
		void print()
		{
			if(heap_size == 0)
			{
				cout<<"HEAP IS EMPTY"<<endl;
				return;
			}
			for(int i = 0 ; i < heap_size ; i++)
			{
				cout<<heap_array[i]<<" ";
			}
			cout<<endl;
		}
		void delete_node(int val)
		{
			if(heap_size == 0)
			{
				cout<<"HEAP IS EMPTY"<<endl;
				return;
			}
			int i = 0;
			while(i != heap_size-1)
			{
				if(heap_array[i] == val)
				{
					heap_array[i] = heap_array[0] + 1;
					break;
				}
				i++;
			}
			swap(&heap_array[i],&heap_array[heap_size-1]);
			heap_size--;
			heapify_up(i);
		}
};
int main()
{
	MaxHeap bin(10);
	bin.insert(5);
	bin.insert(9);
	bin.insert(6);
	bin.insert(7);
	bin.insert(1);
	bin.insert(3);
	bin.insert(8);
	bin.insert(12);
	bin.insert(13);
	bin.insert(14);
	bin.print();
	bin.delete_node(5);
	bin.delete_node(8);
	bin.print();
	return 0;
}

