#include <iostream>
#include<vector>
const int table_size = 200;
using namespace std;
class HashTableEntry
 {
	public:
		int v, k;
		HashTableEntry *next;
		HashTableEntry()
		{
    		next = NULL;
		}	
		HashTableEntry(int k, int v)
		{
      		this->k = k;
      		this->v = v;
      		this->next = NULL;
   		}
};
class HashMapTable
{
	public:
    	HashTableEntry **ht;
    	HashMapTable()
		{
    		ht = new HashTableEntry*[table_size];
			for (int i = 0; i < table_size; i++)
			{
        	    ht[i] = NULL;
			}
    	}
      //TASK_01
      	int HashFunc(int key)
		{
        	 return key % table_size;
      	}
      //TASK_02
  	    int mid_square_hash(int key)
		{
			int value = key*key;
			int mid = middle_value(value);
			return mid;
		}
		//TASK_03
		int Folding_hash(int key)
		{
			return fold_value(key)%table_size;
		}
		//TASK_04
		int radix_hash(int value)
		{
			int result= base _number(value)
			return result;
			// return last3 digit of result;
			//I am taking last three digits bcz of size 
		}
		int base_number(int value)
		{
			vector<int>list;
			int div = -1,mod;
			while(div != 0)
			{
				mod = value%10;
				list.push_back(mod);
				div = value/10;
				value = div;
			}
			int x = 0,int y = 0;
			int size = list.size();
			int i = size-4 ; 
				x = list[i];
				y = x*10;
				i++;
				x = list[i];
				y += x;
				y *= 10;
				i++;
				x = list[i];
				y += x;
				cout<<y<<endl;
			return y;
		}
		int fold_value(int value)
		{
			vector<int>list;
			int div = -1,mod;
			while(div != 0)
			{
				mod = value%1000;
				list.push_back(mod);
				div = value/1000;
				value = div;
			}
			int x;
			int size = list.size();
			for(int i = 0 ; i < (size/2)+1;i++)
			{
				x += list[i];
			}
			return x%table_size;
		}
		
		int middle_value(int value)
		{
			vector<int>list;
			int div = -1,mod;
			while(div != 0)
			{
				mod = value%10;
				list.push_back(mod);
				div = value/10;
				value = div;
			}
			int x;
			int size = list.size();
			for(int i = 0 ; i < (size/2)+1;i++)
			{
				x = list[i];
			}
			return x;
		}
      	void Insert(int k, int v)
	   	{
        	int hash_v = HashFunc(k);
        	HashTableEntry* ptr = ht[hash_v];
         	HashTableEntry* temp = NULL;
         	while(ptr != NULL) 
		 	{
        		temp = ptr;
        		ptr = ptr->next;
         	}
         	if(ptr == NULL)
		  	{
            	ptr = new HashTableEntry;
				ptr->k = k;n
				ptr->v = v;
            	if(temp == NULL)
				{
               		ht[hash_v] = ptr;
            	}
				else 
				{
            	   temp->next = ptr;
            	}
         	}
			else 
			{
            	ptr->v = v;
         	}
      	}
      	void Insert_folding_method(int k, int v)
	   	{
        	int hash_v = Folding_hash(k);
        	HashTableEntry* ptr = ht[hash_v];
         	HashTableEntry* temp = NULL;
         	while(ptr != NULL) 
		 	{
        		temp = ptr;
        		ptr = ptr->next;
         	}
         	if(ptr == NULL)
		  	{
            	ptr = new HashTableEntry;
				ptr->k = k;
				ptr->v = v;
            	if(temp == NULL)
				{
               		ht[hash_v] = ptr;
            	}
				else 
				{
            	   temp->next = ptr;
            	}
         	}
			else 
			{
            	ptr->v = v;
         	}
      	}
      	void Insert_mid_square_value(int k, int v)
	   	{
        	int hash_v = mid_square_hash(k);
        	HashTableEntry* ptr = ht[hash_v];
         	HashTableEntry* temp = NULL;
         	while(ptr != NULL) 
		 	{
        		temp = ptr;
        		ptr = ptr->next;
         	}
         	if(ptr == NULL)
		  	{
            	ptr = new HashTableEntry;
				ptr->k = k;
				ptr->v = v;
            	if(temp == NULL)
				{
               		ht[hash_v] = ptr;
            	}
				else 
				{
            	   temp->next = ptr;
            	}
         	}
			else 
			{
            	ptr->v = v;
         	}
      	}
      	void Remove(int k)
	   	{
        	int hash_v = HashFunc(k);
         	HashTableEntry* ptr = ht[hash_v];
         	HashTableEntry* temp = NULL;
         	if(ptr == NULL || ptr->k != k)
			{	
            	cout<<"KEY DOES NOT FOUND"<<k<<endl;
            	return;
        	}
         	while (ptr->next != NULL) 
		 	{
         	   temp = ptr;
         	   ptr = ptr->next;
         	}
         	if(temp != NULL)
			{
            	temp->next = ptr->next;
         	}
         	delete ptr;
         	cout<<"SUCCESSFULLY DELETED!"<<endl;
      	}
      	void Remove_folding_method(int k)
	   	{
        	int hash_v = Folding_hash(k);
         	HashTableEntry* ptr = ht[hash_v];
         	HashTableEntry* temp = NULL;
         	if(ptr == NULL || ptr->k != k)
			{	
            	cout<<"KEY DOES NOT FOUND"<<k<<endl;
            	return;
        	}
         	while (ptr->next != NULL) 
		 	{
         	   temp = ptr;
         	   ptr = ptr->next;
         	}
         	if(temp != NULL)
			{
            	temp->next = ptr->next;
         	}
         	delete ptr;
         	cout<<"SUCCESSFULLY DELETED!"<<endl;
      	}
      	void Remove_mid_square_value(int k)
	   	{
        	int hash_v = mid_square_hash(k);
         	HashTableEntry* ptr = ht[hash_v];
         	HashTableEntry* temp = NULL;
         	if(ptr == NULL || ptr->k != k)
			{	
            	cout<<"KEY DOES NOT FOUND"<<k<<endl;
            	return;
        	}
         	while (ptr->next != NULL) 
		 	{
         	   temp = ptr;
         	   ptr = ptr->next;
         	}
         	if(temp != NULL)
			{
            	temp->next = ptr->next;
         	}
         	delete ptr;
         	cout<<"SUCCESSFULLY DELETED!"<<endl;
      	}
      	void SearchKey(int k)
		{
        	int hash_v = HashFunc(k);
         	bool flag = false;
         	HashTableEntry* ptr = ht[hash_v];
         	if (ptr != NULL)
		  	{
            	while (ptr != NULL)
				{
               		if (ptr->k == k) 
			   		{
                		flag = true;
               		}	
               		if(flag)
			    	{
                  		cout<<"ELEMENT OF KEY : "<<k<<endl;
                  		cout<<"VALUE AT THAT KEY : "<<ptr->v<<endl<<endl;
               		}
               		ptr = ptr->next;
           		 }
         	}
         	if(!flag)
         	{
           		cout<<"KEY DOES NOT FOUND "<<k<<endl;
		 	}
      	}
      	void SearchKey_folding_method(int k)
		{
        	int hash_v = Folding_hash(k);
         	bool flag = false;
         	HashTableEntry* ptr = ht[hash_v];
         	if (ptr != NULL)
		  	{
            	while (ptr != NULL)
				{
               		if (ptr->k == k) 
			   		{
                		flag = true;
               		}	
               		if(flag)
			    	{
                  		cout<<"ELEMENT OF KEY : "<<k<<endl;
                  		cout<<"VALUE AT THAT KEY : "<<ptr->v<<endl<<endl;
               		}
               		ptr = ptr->next;
           		 }
         	}
         	if(!flag)
         	{
           		cout<<"KEY DOES NOT FOUND "<<k<<endl;
		 	}
      	}
      	void SearchKey_mid_sqaure_value(int k)
		{
        	int hash_v = mid_square_hash(k);
         	bool flag = false;
         	HashTableEntry* ptr = ht[hash_v];
         	if (ptr != NULL)
		  	{
            	while (ptr != NULL)
				{
               		if (ptr->k == k) 
			   		{
                		flag = true;
               		}	
               		if(flag)
			    	{
                  		cout<<"ELEMENT OF KEY : "<<k<<endl;
                  		cout<<"VALUE AT THAT KEY : "<<ptr->v<<endl<<endl;
               		}
               		ptr = ptr->next;
           		 }
         	}
         	if(!flag)
         	{
           		cout<<"KEY DOES NOT FOUND "<<k<<endl;
		 	}
      	}
      	~HashMapTable()
		{
        	delete [] ht;
      	}
};
int main() {
   HashMapTable hash;
	int k,v;
   int c;
   	cout<<"PRESS [1] MODULUS ALGO"<<endl
   		<<"PRESS [2] MID SQUARE ALGO"<<endl
   		<<"PRESS [3] FOLDING METHOD"<<endl;
   		cin>>c;
   		switch(c)
   		{
   			case 1:
   				{
   					while(1) 
					{
				    	cout<<"PRESS [1] INSERTION"<<endl
				      	<<"PRESS [2] SELECTION"<<endl
				      	<<"PRESS [3] DELETION"<<endl
				      	<<"PRESS [4] EXIT"<<endl;
				     	cout<<"Enter your choice: ";
				      	cin>>c;
				      	switch(c)
						{
				         	case 1:
				            	cout<<"ENTER VALUE : ";
				            	cin>>v;
				            	cout<<"ENTER KEY : ";
				            	cin>>k;
				            	hash.Insert(k, v);
				        		 break;
				         	case 2:
				            	cout<<"ENTER KEY : ";
				            	cin>>k;
				            	hash.SearchKey(k);
				        		break;
				        	case 3:
				            	cout<<"ENETR KEY : ";
				            	cin>>k;
				            	hash.Remove(k);
				         		break;
				         	case 5:
				            	exit(1);
				         	default:
				            	cout<<"\nINVALID INPUT\n";
				      	}
				   }
				   break;	
				}
			case 2:
   				{
   					while(1) 
					{
				    cout<<"PRESS [1] INSERTION"<<endl
				      	<<"PRESS [2] SELECTION"<<endl
				      	<<"PRESS [3] DELETION"<<endl
				      	<<"PRESS [4] EXIT"<<endl;
				     	cout<<"Enter your choice: ";
				      	cin>>c;
				      	switch(c)
						{
				         	case 1:
				            	cout<<"ENTER VALUE : ";
				            	cin>>v;
				            	hash.Insert_mid_square_value(v, v);
				        		 break;
				         	case 2:
				            	cout<<"ENTER VALUE : ";
				            	cin>>k;
				            	hash.SearchKey_mid_sqaure_value(k);
				        		break;
				        	case 3:
				            	cout<<"ENTER VALUE : ";
				            	cin>>k;
				            	hash.Remove_mid_square_value(k);
				         		break;
				         	case 5:
				            	exit(1);
				         	default:
				            	cout<<"\nINVALID INPUT\n";
				      	}
				   }
				   break;	
				}
				case 3:
					{
						while(1) 
						{
				    		cout<<"PRESS [1] INSERTION"<<endl
				      		<<"PRESS [2] SELECTION"<<endl
				      		<<"PRESS [3] DELETION"<<endl
				      		<<"PRESS [4] EXIT"<<endl;
				     		cout<<"Enter your choice: ";
				      		cin>>c;
				      		switch(c)
							{
				        	 	case 1:
				        	    	cout<<"ENTER VALUE : ";
					            	cin>>v;
					            	hash.Insert_folding_method(v, v);
					        		 break;
					         	case 2:
					            	cout<<"ENTER VALUE : ";
					            	cin>>k;
					            	hash.SearchKey_folding_method(k);
					        		break;
					        	case 3:
					            	cout<<"ENETR VALUE : ";
					            	cin>>k;
					            	hash.Remove_folding_method(k);
					         		break;
					         	case 5:
					            	exit(1);
					         	default:
					            	cout<<"\nINVALID INPUT\n";
					      	}
					   }
					   break;	
					}
				case 3:
					{
						while(1) 
						{
				    		cout<<"PRESS [1] INSERTION"<<endl
				      		<<"PRESS [2] SELECTION"<<endl
				      		<<"PRESS [3] DELETION"<<endl
				      		<<"PRESS [4] EXIT"<<endl;
				     		cout<<"Enter your choice: ";
				      		cin>>c;
				      		switch(c)
							{
				        	 	case 1:
				        	    	cout<<"ENTER VALUE : ";
					            	cin>>v;
					            	hash.Insert_radix_hash(v, v);
					        		 break;
					         	case 2:
					            	cout<<"ENTER VALUE : ";
					            	cin>>k;
					            	hash.SearchKey_radix_hash(k);
					        		break;
					        	case 3:
					            	cout<<"ENETR VALUE : ";
					            	cin>>k;
					            	hash.Remove_radix_hash(k);
					         		break;
					         	case 5:
					            	exit(1);
					         	default:
					            	cout<<"\nINVALID INPUT\n";
					      	}
					   }
					   break;	
					}
				default:
					cout<<"\nINVALID INPUT\n";   			
		   }
   return 0;
}
