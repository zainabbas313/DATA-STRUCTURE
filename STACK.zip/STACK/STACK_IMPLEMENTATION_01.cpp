#include<iostream>
using namespace std;
class node
{
    public:
        int data;
        node * next;
        node()
        {
            next = NULL;
        }
        node(int data)
        {
            this->data = data;
            next = NULL;
        }
};
class stack
{
    private:
        node * head;
    public:
    stack()
    {
        head = NULL;
    }
    void push(int x)
    {
        node * ptr = new node;
        ptr->data = x;
        if(head == NULL)
        {
            ptr->next = NULL;
            head = ptr;
        }
        else
        {
            node * temp = head;
            ptr->next = temp;
            head = ptr;
        }
    }
    void print_stack_values()
    {
        node * temp = head;
        while(temp != NULL)
        {
            cout<<temp->data<<" ";
            temp = temp->next;
        }
    }
    
};
int main()
{
    stack list;
    list.push(1);
    list.push(2);
    list.push(3);
    list.push(5);
    list.push(6);
    list.push(7);
    list.push(8);
    list.print_stack_values();
    return 0;
}

