#include<iostream>
using namespace std;
class node
{
    public:
        int data;
        node * next;
        node * prev;
        node()
        {
            next = NULL;
            prev = NULL;
        }
        node(int data)
        {
            this->data = data;
            next = prev = NULL;
        }
};
class stack
{
    private:
        node * head;
        node * tail;
    public:
    stack()
    {
        head = NULL;
        tail = NULL;
    }
    void push(int x)
    {
        node * ptr = new node;
        ptr->data = x;
        if(head == NULL)
        {
            ptr->next = NULL;
            ptr->prev = NULL;
            head = tail = ptr;
        }
        else
        {
            node * temp = head;
            temp->prev = ptr;
            ptr->next = temp;
            ptr->prev = NULL;
            head = ptr;
        }
    }
    void print_stack_values_F()
    {
        node * temp = head;
        while(temp != NULL)
        {
            cout<<temp->data<<" ";
            temp = temp->next;
        }
    }
    void print_stack_values_R()
    {
        node * temp = tail;
        while(temp != NULL)
        {
            cout<<temp->data<<" ";
            temp = temp->prev;
        }
    }
    void isEmpty()
    {
    	if(head == NULL)
    	{
    		cout<<endl<<"LIST IS EMPTY"<<endl;
    		return;
		}
		cout<<endl<<"LIST HAVE SOME NODES"<<endl;
	}
    void pop()
    {
        node * temp = head;
        head = head->next;
        delete temp;
    }
    
};
int main()
{
    stack list;
    list.push(1);
    list.push(2);
    list.push(3);
    list.push(4);
    list.push(5);
    list.push(6);
    list.push(7);
    list.push(8);
    list.push(9);
    list.push(10);
    cout<<"STACK VALUES : ";
    list.print_stack_values_F();
    cout<<endl;
    cout<<"STACK VALUS IN REVERSE ORDER : ";
    list.print_stack_values_R();
    list.pop();
    list.pop();
    list.pop();
    list.pop();
    list.pop();
    list.pop();
    list.pop();
    list.pop();
    list.pop();
    list.pop();
    cout<<endl<<"STACK VALUES : ";
    list.print_stack_values_F();
	list.isEmpty();
    return 0;
}

