#include<iostream>
using namespace std;
int count = 0;
class node
{
    public:
        int data;
        node * next;
        node()
        {
            next = NULL;
        }
        node(int data)
        {
            this->data = data;
            next = NULL;
        }
};
class stack
{
    private:
        node * head;
    public:
    stack()
    {
        head = NULL;
    }
    void push(int x)
    {
    	count++;
        node * ptr = new node;
        ptr->data = x;
        if(head == NULL)
        {
            ptr->next = NULL;
            head = ptr;
        }
        else
        {
            node * temp = head;
            ptr->next = temp;
            head = ptr;
        }
    }
    int pop()
    {
    	node* temp = head;
    	int hold = temp->data;
    	head= head->next;
    	delete temp;
    	return hold;
	}
    void print_stack_values()
    {
        node * temp = head;
        while(temp != NULL)
        {
            cout<<temp->data<<" ";
            temp = temp->next;
        }
        cout<<endl;
    }
    bool isEmpty()
    {
    	if(head == NULL)
    	{
    		return true;
		}
		return false;
	}    
	void copy_stack_in_same_order(stack &list1,stack &list2);
};
void copy_stack_in_same_order(stack &list1,stack &list2)
{
	while(!list1.isEmpty())
	{
		int v = list1.pop();
		list2.push(v);		
	}
}
int main()
{
    stack list;
    stack list1;
    stack list2;
    list.push(1);
    list.push(2);
    list.push(3);
    list.push(5);
    list.push(6);
    list.push(7);
    list.push(8);
    cout<<"THE ORIGINAL STACK"<<endl;
    list.print_stack_values();
	copy_stack_in_same_order(list,list1);
//	list1.print_stack_values();
	copy_stack_in_same_order(list1,list2);
//	list2.print_stack_values();
	cout<<"ORIGINAL STACK IN REVERSE ORDER"<<endl; 
	copy_stack_in_same_order(list2,list);
	list.print_stack_values(); 	
}

