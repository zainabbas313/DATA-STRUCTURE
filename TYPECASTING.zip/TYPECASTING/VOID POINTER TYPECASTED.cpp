#include <iostream>
#include <cstdlib>
using namespace std;

int main()
{
	int x = 115;
	void *ptr;
	ptr = &x;
	cout<<*(char*)ptr<<endl;
	cout<<*(int*)ptr<<endl;
	//NULL POINTER
	int *ptr1 = NULL;
	cout<<sizeof(ptr1)<<endl;
	//CONCLUSION: NULL POINTER OCCUPIED SAME BITS AS NORMAL POINTER 
	free(ptr);
	free(ptr1);
	ptr = NULL;
	cout<<ptr;
	
	return 0;
}

