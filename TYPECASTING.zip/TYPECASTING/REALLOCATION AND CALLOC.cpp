#include<iostream>
#include<cstdlib>
using namespace std;
int *fun()
{
	int *ptr, i;
	ptr = (int *)malloc(3*sizeof(int));
	cout<<"ENTER THE 3 NUMBERS : ";
	for( i = 0; i < 3;i++)
	{
		cin>>*(ptr+i);
	}
	return ptr;
}
int main()
{
	int i,*ptr;
	ptr = fun();
	cout<<"THE NUMBERS ARE : ";
	for(i = 0 ; i < 3; i++)
	{
		cout<<*(ptr+i)<<" ";
	}
	cout<<endl;
	ptr = (int *)realloc(ptr,2*sizeof(int));
	cout<<"ENTER THE 2 NUMBERS MORE : ";
	for( i = 3; i < 5;i++)
	{
		cin>>*(ptr+i);
	}
	cout<<"THE NUMBERS ARE : ";
	for(i = 0 ; i < 5; i++)
	{
		cout<<*(ptr+i)<<" ";
	}
	free(ptr);
	ptr = NULL;
	return 0;
}

