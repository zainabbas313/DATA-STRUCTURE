#include<iostream>
using namespace std;

int main()
{
	int a;
	double b = 2.3445;
	a = b; //implicit typecasting
	cout<<a<<endl;
	
	b = 2.34455;
	a = (int)b; //explicit typecasting in c style
	cout<<a<<endl;
	
	b = 3.4554;
	a = int(b); //explict typecasting is c++ style
	cout<<a<<endl;
	
	return 0;
}

