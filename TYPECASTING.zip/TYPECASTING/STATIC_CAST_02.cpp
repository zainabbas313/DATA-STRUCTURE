#include<iostream>
using namespace std;
int main()
{
	int a = 5, b = 2;
	double ans;
	//static_cast a to ans
	ans = static_cast<double>(a)/b;
	cout<<ans<<endl;
	return 0;
}

