#include<iostream>
#include<cstdlib>
using namespace std;

int main()
{
	int  var = 10;
	int *ptr;//--->wild pointer
	//to point a pointer like this, this may cause program to misbehave or cause an error
	//*ptr = 10; 

	ptr = &var;//-->now the pointer in no more a wild pointer
	
	//good practice
	int * p = (int *)malloc(sizeof(int));
	free(p);
	p = NULL;
	return 0;
}

