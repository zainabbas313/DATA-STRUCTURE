#include <iostream>
using namespace std;
//here we make some function
int addition(int a, int b)
{ 
	return (a+b);
}
int subtraction(int a, int b)
{ 
	return (a-b); 
}
//in this function: two arg of int type and one is the pointer of function
//that identify the function to call at runtime, providing that the address of that function
int operation(int x, int y, int (*func_to_call)(int,int))
{
	int g;
	g = (*func_to_call)(x,y);
	return (g);
}
int main ()
{
	 int m,n;
	 int (*minus)(int,int) = subtraction;
	 m = operation (7, 5, addition);
	 cout<<m<<endl;
	 n = operation (20, m, minus);
	 cout <<n;
	 return 0;
}

