#include<iostream>
#include<fstream>
#include<sstream>
using namespace std;
class node
{
	public:
		bool frd;
		string node_name;
		string frd_name;
		node* down;
		node* left;	
		node()
		{
			down = left = NULL;
			frd = false;
		}
		node(bool frd,string node_name)
		{
			this->frd = frd;
			this->node_name = node_name;
			down = left = NULL;
		}
};
class graph
{
	private:
		node* head;
	public:
		graph()
		{
			head = NULL;
		}
		graph(string name)
		{
			node* ptr = new node;
			ptr->node_name = name;
			head = ptr;
			ptr->down = NULL;	
		}	
		void insert(string name)
		{
			node* ptr = new node;
			ptr->node_name = name;
			if(head == NULL)
			{
				head = ptr;
				ptr->down = NULL;
				return;
			}
			node* temp = head;
			while(temp->down != NULL)
			{
				temp = temp->down;
			}
			temp->down = ptr;
			ptr->down = NULL;
		}
		void print_node()
		{
			node* temp = head;
			while(temp != NULL)
			{
				cout<<temp->node_name<<" ";
				temp = temp->down;
			}
			cout<<endl;
		}
		void print_link_of_node(string name)
		{
			node* temp = head;
			node* temp1 = head;
			while(temp != NULL)
			{
				temp1 = temp;
				if(temp->node_name == name)
				{
					cout<<"LINKS OF "<<name<<" : ";
					while(temp1 != NULL)
					{
						cout<<temp1->frd_name<<" ->";
						temp1 = temp1->left;
					}
					break;
				}
				temp = temp->down;
			}
			cout<<endl;
		}
		void insert_link()
		{
			string d_name,l_name;
			int x = 1;
			while(x != 0)
			{
				cout<<"THE AVAILABLE NODE OF GARPH ARE : ";
				print_node();
				cout<<"ENTER THE NODE NAME FROM WHICH YOU WANT TO MAKE LINK : ";
				cin>>d_name;
				cout<<"ENTER THE NODE NAME TO WHICH YOU TO CONNECT : ";
				cin>>l_name;
				node* temp = head;
				while(temp != NULL)
				{
					if(temp->node_name == d_name)
					{
						node* temp2 = head;
						node* ptr = new node;
						ptr->frd_name = l_name;
						ptr->frd = true;
						while(temp->left != NULL)
						{
							temp = temp->left;
						}
						temp->left = ptr;
						ptr->left = NULL;
						break;
					}
					temp = temp->down;
				}				
				cout<<"PRESS [1] TO MAKE FURTHER LINKS"<<endl
					<<"PRESS [0] TO EXIT : \t";
					cin>>x;
			}
		}
		void display_graph()
		{
			node* temp1 = head;
			node* temp2 = head;
			while(temp1 != NULL)
			{
				cout<<temp1->node_name;
				temp2 = temp1;
				while(temp2 != NULL)
				{
					cout<<temp2->frd_name<<"->";
					temp2 = temp2->left;
				}
				temp1 = temp1->down;
				cout<<endl<<"|"<<endl;
			}
		}
};
int main()
{
	graph list;
	list.insert("A");
	list.insert("B");
	list.insert("C");
	list.insert("D");
	list.insert("E");
	list.print_node();
	list.insert_link();
	list.display_graph();
	list.print_link_of_node("E");
	return 0;
}

