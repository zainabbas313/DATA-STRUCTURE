#include<vector>
#include<queue>
#include<iostream>
#include<bits/stdc++.h>
using namespace std;

class Graph
{
	int V;
	vector< list<int> > adj;
public:
	Graph(int V)
	{
	    this->V = V;
	    adj.resize(V);
    }
	
	void add_edge(int v1, int v2)
	{
	    adj[v1].push_back(v2);
    }
    void DFS(int v)//DFS traversal for vertex
	{
	    vector<bool> vis;
		vis.resize(V,false);
		
	    vis[v] = true;
	    cout << v << endl;
	 
	    list<int>::iterator i;
	    for (i = adj[v].begin(); i != adj[v].end(); ++i)
	        if (!vis[*i])
	            DFS(*i);
	}
	void BFS(int v)//BFS traversal for vertex
	{
		vector<bool> vis;
		vis.resize(V,false);
		
		list<int> queue;
		
		vis[v] = true;
		queue.push_back(v);
		
		while(!queue.empty())
		{
			v = queue.front();
			cout << v << endl;
			queue.pop_front();
			for (auto_adjacent:: adj[v])
			{
				if (!vis[adjacent])
				{
					vis[adjacent] = true;
					queue.push_back(adjacent);
				}
			}
        }
    }
};


int main()
{
	
	Graph link(8);
	link.add_edge(0, 1);
	link.add_edge(0, 2);
	link.add_edge(1, 3);
	link.add_edge(1, 4);
	link.add_edge(1, 5);
	link.add_edge(3, 6);
	link.add_edge(3, 7);

	cout << "(BFS)Breadth First Search Traversal \n";
	link.BFS(1);
	cout << "\n(DFS)Depth First Search Traversal \n";
	link.DFS(1);
	return 0;
}
