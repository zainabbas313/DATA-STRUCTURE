#include<iostream>
#include<vector>
using namespace std;
class graph_node
{
	public:
		bool link;
		int i ;
		string edge;
		graph()
		{
			i = 0;
			link = false;
		}
		graph(bool link,string edge)
		{
			i = 0;
			this->link = link;
			this->edge = edge;
		}
};
class graph : public graph_node
{
	public:
		vector<vector<string>> list;
		graph()
		{
			list.resize(2);
		}
		void insert(string edge)
		{
			list[i].push_back(edge);
			i++;
		}
		void insert_link(char edge,char linking_edge)
		{
			for(int i = 0 ; i < list.size()-1; i++)
			{
				if(list[i][0] == linking_edge)
				{
					for(int j = 0; j < list.size();j++)
					{
						if(edge == list[j][0])
						{
							list[j].push_back(linking_edge);
							break;
						}
					}
					return;
				}
			}
			cout<<"LINKING EDGE IS NOT FOUND"<<endl;
		}
};

int main()
{
	vector<vector<char>> list;
	list.resize(5);
	list[0].push_back('a');
	list[1].push_back('b');
	list[2].push_back('c');
	list[3].push_back('d');
	insert(list,'a','c');
	insert(list,'a','d');
	insert(list,'b','a');
	insert(list,'c','f');
	insert(list,'c','a');
	insert(list,'d','d');
	cout<<" ";
	for(int i = 0 ; i < list.size(); i++)
	{
		for(int j = 0; j < list[i].size(); j++)
		{
			cout<<list[i][j]<<" ";
		}
		cout<<endl;
	}
	for(int i = 0 ; i < list.size(); i++)
	{
		cout<<list[i][0]<<" ";
	}
	cout<<endl;
	for(int i = 0; i < list.size();i++)
	{
		cout<<list[i][0]<< " ";
		for(int j = 0 ; j < list.size();j++)
		{
			if(list[i][j] = )
		}
	}
	return 0;
}

