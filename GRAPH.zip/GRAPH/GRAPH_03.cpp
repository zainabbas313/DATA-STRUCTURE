#include<iostream>
#include<vector>
using namespace std;
class q_node
{
	public:
		string data;
		q_node* next;
		q_node* prev;
		q_node()
		{
			next = prev = NULL;
		}
		q_node(string data)
		{
			prev = next = NULL;
			this->data = data;
		}
};
class queue
{
	private:
		q_node* head;
	public:
		queue()
		{
			head = NULL;
		}
		queue(string val)
		{
			q_node* ptr = new q_node;
			ptr->data = val;
			ptr->next = ptr->prev = NULL;
			head = ptr;
		}
		void enqueue(string val)
		{
			q_node* ptr = new q_node;
			ptr->data = val;
			if(head == NULL)
			{
				ptr->next = ptr->prev = NULL;
				head = ptr;
				return;
			}
			q_node* temp = head;
			while(temp->next != NULL)
			{
				temp = temp->next;
			}
			temp->next = ptr;
			ptr->next = NULL;
			ptr->prev = temp;
		}
		string dequeue()
		{
			if(head != NULL)
			{
				q_node* temp = head;
				string val = temp->data;
				head = head->next;
				return val;
			}
			cout<<"QUEUE EMPTY"<<endl;
		}
		void display()
		{
			q_node* temp = head;
			while(temp != NULL)
			{
				cout<<temp->data<<" ";
				temp = temp->next;
			}
			cout<<endl;
		}
		bool isEmpty()
		{
			if(head == NULL)
			{
				return true;
			}
			return false;
		}
};
class s_node
{
	public:
		string data;
		s_node* next;
		s_node* prev;
		s_node()
		{
			next = prev = NULL;
		}
		s_node(string data)
		{
			prev = next = NULL;
			this->data = data;
		}
};
class stack
{
	private:
		s_node* head;
	public:
		stack()
		{
			head = NULL;
		}
		stack(string val)
		{
			s_node* ptr = new s_node;
			ptr->data = val;
			ptr->next = ptr->prev = NULL;
			head = ptr;
		}
		void push(string val)
		{
			s_node* ptr = new s_node;
			ptr->data = val;
			if(head == NULL)
			{
				ptr->next = ptr->prev = NULL;
				head = ptr;
				return;
			}
			s_node* temp = head;
			temp->prev = ptr;
			ptr->next = temp;
			ptr->prev = NULL;
			head = ptr;
		}
		string pop()
		{
			if(head != NULL)
			{
				s_node* temp = head;
				string val = temp->data;
				head = head->next;
				return val;
			}
			cout<<"STACK OVERFLOW!"<<endl;
		}
		void display()
		{
			if(head != NULL)
			{
				s_node* temp = head;
				while(temp != NULL)
				{
					cout<<temp->data<<" ";
					temp = temp->next;
				}
				cout<<endl;
			}
			else
			{
				cout<<"STACK IS EMPTY!"<<endl;
			}
		}
};
class node
{
	public:
		string vertex;
		int s_visited;
		int q_visited;
		vector<string> vec;
		node* next;
		node()
		{
			s_visited = 0;
			q_visited = 0;
			next = NULL;	
		}	
		node(string vertex)
		{
			s_visited = 0;
			q_visited = 0;
			this->vertex = vertex;
		}
};
class graph
{
	private:
		node* head;
		int** adj = new int*[50];
		int size;
	public:
		stack c;//object of stack class for dfs
		queue q;//object of queue class for bfs
		stack t;//object of stack class for topoligical sort
		graph()
		{
			head = NULL;
			size = 0;
			for(int i = 0 ; i < 50; i++)
			{
				adj[i] = new int[50];
			}
			for(int i = 0; i < 50;i++)
			{
				for(int j = 0 ; j < 50; j++)
				{
					adj[i][j] = 0;
				}
			}
		}
		graph(string ver)
		{
			node* ptr = new node;
			for(int i = 0 ; i < 50; i++)
			{
				adj[i] = new int[50];
			}
			for(int i = 0; i < 50;i++)
			{
				for(int j = 0 ; j < 50; j++)
				{
					adj[i][j] = 0;
				}
			}
			size++;
			ptr->vertex = ver;
			ptr->q_visited = 0;
			ptr->s_visited = 0;
			ptr->next = NULL;
			head = ptr;
		}
		void insert_vertex(string ver)
		{
//			string ver;
//			cout<<"ENTER THE VERTEX NAME : ";
//			cin>>ver;
			node* hold = head;
			while(hold != NULL)
			{
				if(hold->vertex == ver)
				{
					cout<<"ALREADY EXIST!"<<endl;
					return;
				}
				hold = hold->next;
			}
			size++;
			node* ptr = new node;
			ptr->vertex = ver;
			ptr->q_visited = 0;
			ptr->s_visited = 0;
			if(head == NULL)
			{
				ptr->next = NULL;
				head = ptr;
				return;	
			}
			node* temp = head;
			while(temp->next != NULL)
			{
				temp = temp->next;
			}
			temp->next = ptr;
			ptr->next = NULL;
		}
		void call_dfs()
		{
			node* temp = head;
			cout<<"DFS : ";
			dfs(temp);
			cout<<c.pop()<<endl;
		}
		node* dfs(node* temp)
		{
			c.push(temp->vertex);
			temp->s_visited = 1;
			node* hold = head;
			for(int i = 0; i < temp->vec.size();i++)
			{
				hold = head;
				while(hold != NULL)
				{
					if(hold->vertex == temp->vec[i] && hold->s_visited == 0)
					{
						dfs(hold);
						cout<<c.pop()<<" ";
					}
					hold = hold->next;
				}
			}
		}
		void call_bfs()
		{
			node* temp = head;
			cout<<"BFS : ";
			q.enqueue(temp->vertex);
			temp->q_visited = 1;
			cout<<q.dequeue()<<" ";
			bfs(temp);
//			cout<<q.dequeue()<<"......"<<endl;
		}
		node* bfs(node* temp1)
		{
			if(temp1 == NULL)
			{
				return NULL;
			}
			node* temp = head;
			for(int i = 0 ; i < temp1->vec.size();i++)
			{
				while(temp != NULL)
				{
					if(temp->vertex == temp1->vec[i] && temp->q_visited == 0)
					{
						q.enqueue(temp->vertex);
						temp->q_visited = 1;
					}
					temp = temp->next;
				}
				temp = head;
			}
			if(!q.isEmpty())
			{
				node* temp2 = head;
				string ver = q.dequeue();
				cout<<ver<<" ";
				while(temp2 != NULL)
				{
					if(temp2->vertex == ver)
					{
						bfs(temp2);
						break;
					}
					temp2 = temp2->next;
				}
			}
		}
		void convert_into_directed_graph()
		{
			int i = 0,j = 0;
			node* temp = head;
			//delete the loop with itself
			while(temp != NULL)
			{
				for(int a = 0 ;a < temp->vec.size();a++)
				{
					if(temp->vertex == temp->vec[a])
					{
						node* hold = head;
						while(hold != NULL)
						{
							if(hold->vertex == temp->vertex)
							{
								adj[i][j] = 0;
							}
							j++;
							hold = hold->next;
						}j=0;
					}
				}
				i++;
				temp = temp->next;
			}
		}
		void insert_link(string ver,string linking_vertex)
		{
//			string ver, linking_vertex;
//			cout<<"ENTER VERTEX NAME FROM WHICH A LINK CREATE : ";
//			cin>>ver;
//			cout<<"ENTER VERTEX NAME TO WHICH A LINK CREATE : ";
//			cin>>linking_vertex;
			node* temp1 = head;
			while(temp1 != NULL)
			{
				if(temp1->vertex == ver)
				{
					for(int i = 0 ; i < temp1->vec.size();i++)
					{
						if(linking_vertex == temp1->vec[i])
						{
							cout<<"ALREADY LINKED!"<<endl;
							return;
						}
					}
				}
				temp1 = temp1->next;
			}
			temp1 = head;
			int i = 0, j = 0;
			while(temp1 != NULL)
			{
				if(temp1->vertex == linking_vertex)
				{
					node* temp = head;
					while(temp != NULL)
					{
						if(temp->vertex == ver)
						{
							temp->vec.push_back(linking_vertex);
							adj[i][j] = 1;
							sort(temp);
							break;
						}
						i++;
						temp = temp->next;
					}
					return;
				}
				i = 0;
				j++;
				temp1 = temp1->next;
			}
			cout<<"LINK VERTEX IS NOT FOUND!"<<endl;
		}
		void sort(node* temp)
		{
			for(int i = 0; i < temp->vec.size();i++)
			{
				for(int j = 0; j < temp->vec.size();j++)
				{
					if(temp->vec[i] < temp->vec[j])
					{
						string hold = temp->vec[i];
						temp->vec[i] = temp->vec[j];
						temp->vec[j] = hold;  
					}
				}
			}
		}
		void adjacency_list()
		{
			node* temp = head;
			while(temp != NULL)
			{
				cout<<temp->vertex<<" -> ";
				for(int i = 0 ;i < temp->vec.size();i++)
				{
					cout<<temp->vec[i]<<" ";
				}
				cout<<endl;
				temp = temp->next;
			}
		}
		void adjacency_matrix()
		{
			node* temp = head;
			cout<<"     ";
			while(temp != NULL)
			{
				cout<<temp->vertex<<"   ";
				temp = temp->next;
			}
			cout<<endl;
			temp = head;
			while(temp != NULL)
			{
				for(int i = 0; i < size;i++)
				{
					cout<<temp->vertex<<"    ";
					for(int j = 0 ; j < size ; j++)
					{
						cout<<adj[i][j]<<"   ";
					}
					temp = temp->next;
					cout<<endl;
				}
			}
		}
};
int main()
{
	graph g;
	g.insert_vertex("A");
	g.insert_vertex("B");
	g.insert_vertex("C");
	g.insert_vertex("D");
	g.insert_vertex("E");
	g.insert_vertex("F");
	g.insert_vertex("G");
	g.insert_vertex("H");
	g.insert_vertex("I");
	
	g.insert_link("A","A");
	g.insert_link("A","H");
	g.insert_link("B","C");
	g.insert_link("B","H");
	g.insert_link("C","B");
	g.insert_link("C","I");
	g.insert_link("C","D");
	g.insert_link("C","F");
	g.insert_link("D","C");
	g.insert_link("D","E");
	g.insert_link("D","F");
	g.insert_link("E","D");
	g.insert_link("E","F");
	g.insert_link("F","E");
	g.insert_link("F","D");
	g.insert_link("F","C");
	g.insert_link("G","G");
	g.insert_link("G","H");
	g.insert_link("G","I");
	g.insert_link("H","H");
	g.insert_link("H","A");
	g.insert_link("H","B");
	g.insert_link("H","I");
	g.insert_link("I","C");
	g.insert_link("I","G");
	g.insert_link("I","I");
	cout<<"DEPTH FRIST SEARCH"<<endl;
	g.call_dfs();
	cout<<"BREATH FRIST SEARCH"<<endl;
	g.call_bfs();
	cout<<endl;
	cout<<"ADJACENCY LIST"<<endl;
	g.adjacency_list();
	cout<<"ADJACENCY MATRIX"<<endl;
	g.adjacency_matrix();
	g.convert_into_directed_graph();
	cout<<"ADJACENCY LIST"<<endl;
	g.adjacency_list();
	cout<<"ADJACENCY MATRIX"<<endl;
	g.adjacency_matrix();
	return 0;
}
