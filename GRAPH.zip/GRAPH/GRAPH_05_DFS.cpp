#include<iostream>
#include<vector>
using namespace std;
int size = 0;
class q_node
{
	public:
		string data;
		q_node* next;
		q_node* prev;
		q_node()
		{
			next = prev = NULL;
		}
		q_node(string data)
		{
			prev = next = NULL;
			this->data = data;
		}
};
class queue
{
	private:
		q_node* head;
	public:
		queue()
		{
			head = NULL;
		}
		queue(string val)
		{
			q_node* ptr = new q_node;
			ptr->data = val;
			ptr->next = ptr->prev = NULL;
			head = ptr;
		}
		void enqueue(string val)
		{
			q_node* ptr = new q_node;
			ptr->data = val;
			if(head == NULL)
			{
				ptr->next = ptr->prev = NULL;
				head = ptr;
				return;
			}
			q_node* temp = head;
			while(temp->next != NULL)
			{
				temp = temp->next;
			}
			temp->next = ptr;
			ptr->next = NULL;
			ptr->prev = temp;
		}
		string dequeue()
		{
			if(head != NULL)
			{
				q_node* temp = head;
				string val = temp->data;
				head = head->next;
				return val;
			}
			cout<<"QUEUE EMPTY"<<endl;
		}
		void display()
		{
			q_node* temp = head;
			while(temp != NULL)
			{
				cout<<temp->data<<" ";
				temp = temp->next;
			}
			cout<<endl;
		}
};
class s_node
{
	public:
		string data;
		s_node* next;
		s_node* prev;
		s_node()
		{
			next = prev = NULL;
		}
		s_node(string data)
		{
			prev = next = NULL;
			this->data = data;
		}
};
class stack
{
	private:
		s_node* head;
	public:
		stack()
		{
			head = NULL;
		}
		stack(string val)
		{
			s_node* ptr = new s_node;
			ptr->data = val;
			ptr->next = ptr->prev = NULL;
			head = ptr;
		}
		void push(string val)
		{
			s_node* ptr = new s_node;
			ptr->data = val;
			if(head == NULL)
			{
				ptr->next = ptr->prev = NULL;
				head = ptr;
				return;
			}
			s_node* temp = head;
			temp->prev = ptr;
			ptr->next = temp;
			ptr->prev = NULL;
			head = ptr;
		}
		string pop()
		{
			if(head != NULL)
			{
				s_node* temp = head;
				string val = temp->data;
				head = head->next;
				return val;
			}
			cout<<"STACK OVERFLOW!"<<endl;
		}
		void display()
		{
			if(head != NULL)
			{
				s_node* temp = head;
				while(temp != NULL)
				{
					cout<<temp->data<<" ";
					temp = temp->next;
				}
				cout<<endl;
			}
			else
			{
				cout<<"STACK IS EMPTY!"<<endl;
			}
		}
};
class node
{
	public:
		string vertex;
		int s_visited;
		int q_visited;
		vector<string> vec;
		node* next;
		node()
		{
			s_visited = q_visited = 0;
			next = NULL;	
		}	
		node(string vertex)
		{
			s_visited = q_visited = 0;
			this->vertex = vertex;
		}
};
class graph
{
	private:
		node* head;
	public:
		stack c;
		queue q;
		graph()
		{
			head = NULL;
		}
		graph(string ver)
		{
			node* ptr = new node;
			ptr->vertex = ver;
			ptr->next = NULL;
			head = ptr;
			size++;
		}
		void insert_vertex(string ver)
		{
//			string ver;
//			cout<<"ENTER THE VERTEX NAME : ";
//			cin>>ver;
			node* hold = head;
			while(hold != NULL)
			{
				if(hold->vertex == ver)
				{
					cout<<"ALREADY EXIST!"<<endl;
					return;
				}
				hold = hold->next;
			}
			node* ptr = new node;
			ptr->vertex = ver;
			if(head == NULL)
			{
				ptr->next = NULL;
				head = ptr;
				size++;
				return;	
			}
			node* temp = head;
			while(temp->next != NULL)
			{
				temp = temp->next;
			}
			temp->next = ptr;
			ptr->next = NULL;
			size++;
		}
		void call_dfs()
		{
			node* temp = head;
			cout<<"DFS : ";
			dfs(temp);
			cout<<c.pop()<<endl;
		}
		node* dfs(node* temp)
		{
			c.push(temp->vertex);
			temp->s_visited = 1;
			while(temp != NULL)
			{
				node* hold = head;
				if(temp->vec.size() != 0)
				{
					while(hold != NULL)
					{
						static int flag = 0;
						for(int i = 0; i < temp->vec.size();i++)
						{
							if(hold->vertex == temp->vec[i] && hold->s_visited == 0)
							{
								flag++;
								dfs(hold);
								cout<<c.pop()<<" "; 
							}
						}
						hold = hold->next;
					}
				}
				temp = temp->next;
			}
		}
		void call_bfs()
		{
			node* temp = head;
			cout<<"BFS : ";
			bfs(temp);
			cout<<q.dequeue()<<endl;
		}
		node* bfs(node* temp)
		{
			q.enqueue(temp->vertex);
			temp->q_visited = 1;
			while(temp != NULL)
			{
				node* hold = head;
				if(temp->vec.size() != 0)
				{
					while(hold != NULL)
					{
						static int flag = 0;
						for(int i = 0; i < temp->vec.size();i++)
						{
							if(hold->vertex == temp->vec[i] && hold->q_visited == 0)
							{
								flag++;
								bfs(hold);
								cout<<q.dequeue()<<" "; 
							}
						}
						hold = hold->next;
					}
				}
				temp = temp->next;
			}
		}
		void insert_link(string ver,string linking_vertex)
		{
//			string ver, linking_vertex;
//			cout<<"ENTER VERTEX NAME FROM WHICH A LINK CREATE : ";
//			cin>>ver;
//			cout<<"ENTER VERTEX NAME TO WHICH A LINK CREATE : ";
//			cin>>linking_vertex;
			node* temp1 = head;
			while(temp1 != NULL)
			{
				if(temp1->vertex == ver)
				{
					for(int i = 0 ; i < temp1->vec.size();i++)
					{
						if(linking_vertex == temp1->vec[i])
						{
							cout<<"ALREADY LINKED!"<<endl;
							return;
						}
					}
				}
				temp1 = temp1->next;
			}
			temp1 = head;
			while(temp1 != NULL)
			{
				if(temp1->vertex == linking_vertex)
				{
					node* temp = head;
					while(temp != NULL)
					{
						if(temp->vertex == ver)
						{
							temp->vec.push_back(linking_vertex);
							sort(temp);
							break;
						}
						temp = temp->next;
					}
					return;
				}
				temp1 = temp1->next;
			}
			cout<<"LINK VERTEX IS NOT FOUND!"<<endl;
		}
		void sort(node* temp)
		{
			for(int i = 0; i < temp->vec.size();i++)
			{
				for(int j = 0; j < temp->vec.size();j++)
				{
					if(temp->vec[i] < temp->vec[j])
					{
						string hold = temp->vec[i];
						temp->vec[i] = temp->vec[j];
						temp->vec[j] = hold;  
					}
				}
			}
		}
		void adjacency_list()
		{
			node* temp = head;
			while(temp != NULL)
			{
				cout<<temp->vertex<<" -> ";
				for(int i = 0 ;i < temp->vec.size();i++)
				{
					cout<<temp->vec[i]<<" ";
				}
				cout<<endl;
				temp = temp->next;
			}
		}
		void adjacency_matrix()
		{
			node* temp = head;
			cout<<"     ";
			while(temp != NULL)
			{
				cout<<temp->vertex<<"   ";
				temp = temp->next;
			}
			cout<<endl;
			temp = head;
			int i = 0,it = 0,j=0;
			node* hold = head;
			while(temp != NULL)
			{
				cout<<temp->vertex<<"    ";
				int size = temp->vec.size();
				if(size != 0)
				{
					while(hold != NULL)
					{
						for(j = 0 ; j < size;j++)
						{
							if(hold->vertex == temp->vec[j])
							{
								cout<<"1"<<"   ";
								i = 1;
							}
						}
						if(i != 1)
						{
							cout<<"0"<<"   ";
							it++;
						}
						i = 0;
						hold = hold->next;
					}
				}
				else
				{
					while(hold != NULL)
					{
						cout<<"0"<<"   ";
						hold = hold->next;
					}
				}
				i = 0;
				hold = head;
				cout<<endl;
				it++;
				temp = temp->next;
			}
			
		}
};
int main()
{
	graph g;
	g.insert_vertex("A");
	g.insert_vertex("B");
	g.insert_vertex("C");
	g.insert_vertex("D");
	g.insert_vertex("E");
	g.insert_vertex("F");
	g.insert_vertex("G");
	g.insert_vertex("H");
	g.insert_vertex("K");
	
	g.insert_link("A","A");
	g.insert_link("A","D");
	g.insert_link("B","B");
	g.insert_link("B","D");
	g.insert_link("B","K");
	g.insert_link("C","C");
	g.insert_link("C","F");
	g.insert_link("D","A");
	g.insert_link("D","B");
	g.insert_link("D","E");
	g.insert_link("D","G");
	g.insert_link("E","D");
	g.insert_link("E","F");
	g.insert_link("E","G");
	g.insert_link("E","H");
	g.insert_link("F","C");
	g.insert_link("F","E");
	g.insert_link("F","H");
	g.insert_link("F","K");
	g.insert_link("G","D");
	g.insert_link("G","E");
	g.insert_link("G","H");
	g.insert_link("H","E");
	g.insert_link("H","F");
	g.insert_link("H","G");
	g.insert_link("K","F");
	g.insert_link("K","B");
	g.call_dfs();
	g.call_bfs();
	cout<<endl;
	g.adjacency_list();
	g.adjacency_matrix();
	return 0;
}
