#include<iostream>
#include<vector>
using namespace std;
int it = 0 ;
void insert(vector<vector<string>>&graph,string edge)
{
    graph[it].push_back(edge);
    it++;
}
void insert_link(vector<vector<string>>&list,string edge,string linking_edge)
{
    int count = 0;
    for(int i = 0;i < list.size();i++)
    {
        if(list[i][0] == edge)
        {
            count++;
            break;
        }
    }
	if(count != 0)
	{
	    for(int i = 0 ; i < list.size(); i++)
    	{
    		if(list[i][0] == linking_edge)
    		{
    			for(int j = 0; j < list.size();j++)
    			{
    				if(edge == list[j][0])
    				{
    					list[j].push_back(linking_edge);
    					break;
    				}
    			}
    		    return;
    		}
    	}
	    cout<<"LINKING EDGE IS NOT FOUND"<<endl;
	}
	else
	{
	    cout<<"THIS EDGE IS NOT FOUND"<<endl;
	}
}
void display(vector<vector<string>>&graph)
{
    for(auto& i : graph)
    {
        for(auto j: i)
        {
            cout<<j<<" ";
        }
    }
}
void display_loop(vector<vector<string>>&graph)
{
    for(int i = 0 ; i < graph.size(); i++)
    {
        for(int j = 0 ; j < graph[i].size();j++)
        {
            cout<<graph[i][j]<<" ";
        }
        cout<<endl;
    }
}
int main()
{
    vector<vector<string>> graph;
    graph.resize(5);
    insert(graph,"A");
    insert(graph,"B");
    insert(graph,"C");
    insert(graph,"D");
    insert(graph,"E");
    insert_link(graph,"A","C");
    insert_link(graph,"B","C");
    insert_link(graph,"e","B");
    insert_link(graph,"C","f");
    display_loop(graph);
}
