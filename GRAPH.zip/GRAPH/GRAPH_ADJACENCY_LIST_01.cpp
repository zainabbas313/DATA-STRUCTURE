#include<iostream>
using namespace std;
class linking;
class list_node;
class node 
{
	public:
		char node_name;
		node* next;
		node()
		{
			next = NULL;
//			sub_list_head = NULL;
		}
		node(char node_name)
		{
			this->node_name = node_name;
			next = NULL;
//			sub_list_head = NULL;
		}
};
class verties
{
	public:
		list_node* sub_list_head;
		verties()
		{
			
		}
		verties(node* head,char name)
		{
			node* ptr = new node();
			ptr->node_name = name;
			head = ptr;
			ptr->next = NULL;	
		}
		void insert(node* head,char name)
		{
			node* ptr = new node;
			ptr->node_name = name;
			if(head == NULL)
			{
				head = ptr;
				ptr->next;
				return;
			}
			node* temp;
			while(temp->next != NULL)
			{
				temp = temp->next;
			}
			temp->next = ptr;
			ptr->next = NULL;
		}
};
class list_node
{
	public:
		char vertex_name;
		bool link;
		list_node* next;	
		list_node()
		{
			next = NULL;
			link  = 0;
		}
		list_node(bool link,char vertex_name)
		{
			this->vertex_name = vertex_name;
			this->link = link;
		}
};

class linking
{
	private:
		list_node* list_head;
	public:
		linking()
		{
			list_head = NULL;
		}
		linking(bool val,char ver)
		{
			list_node* ptr = new list_node;
			ptr->link = val;
			ptr->vertex_name = ver;
			list_head = ptr;
			ptr->next = NULL;
		}
		void make_link(bool val,char ver,node* head)
		{
			list_node* ptr = new list_node;
			ptr->link = val;
			ptr->vertex_name = ver;
			if(head == NULL)
			{
				list_head = ptr;
				ptr->next = NULL;
				return;
			}
			list_node* temp = list_head;
			while(temp->next != NULL)
			{
				temp = temp->next;
			}
			temp->next = ptr;
			ptr->next= NULL;
		}
			
};
int main()
{
	int num;
	node* head = NULL;
	node* temp = head;
	list_node* head1 = NULL;
	char name;
	verties list[5];
	linking ptr;
	cout<<"NUMBER OF NODES IN GRAPH : 	";
	cin>>num;
		for(int i =0 ; i < num; i++)
		{
			cout<<"GRAPH NODE NAME : 	";
			cin>>name;
			list[i].insert(head,name);
//			list[i].sub_list_head = ptr;
			cout<<"CONNECT TO VERTEX : ";
			cin>>name;
//			ptr->make_link(1,name);
		}
	return 0;
	
}











