#include<iostream>
#include<vector>
using namespace std;
class MinHeap
{
	private:
	public:
		int *arr;
		int capacity;
		int heap_size;
		MinHeap()
		{
			capacity = 0;
			arr = NULL;
		}
		MinHeap(int capacity)
		{
			heap_size = 0;
			this->capacity = capacity;
			arr = new int[capacity];
		}
		void insert(int val)
		{
			arr[heap_size] = val;
			int i = heap_size; 
			heap_size++;
			while(i != 0 && arr[i] < arr[parent(i)])
			{
				swap(arr[parent(i)],arr[i]);
				i = parent(i);
			}
		}
		void heapify(int index)
		{
			int l = left(index);
			int r = right(index);
			int smallest = index;
			if(heap_size > l && heap_size > r)
			{
				if(arr[l] > arr[r])
				{
					smallest = r;
				}
				else
				{
					smallest = l;
				}
			}
			if(smallest != index && arr[index] > arr[smallest])
			{
				swap(arr[index],arr[smallest]);
				heapify(smallest);
			}
		}
		void delete_node(int val)
		{
			int i = 0;
			for(i = 0; i < heap_size;i++)
			{
				if(arr[i] == val)
				{
					arr[i] = arr[0] - 1;
					break;
				}
			}
			swap(arr[i],arr[heap_size-1]);
			heap_size--;
			heapify(i);
		}
		void display()
		{
			for(int i = 0 ; i < heap_size;i++)
			{
				cout<<arr[i]<<" ";
			}
			cout<<endl;
		}
		void swap(int &x,int &y)
		{
			int temp = x;
			x = y;
			y = temp;
		}
		int parent(int index)
		{
			return (index-1)/2;
		}
		int left(int index)
		{
			return (2*index+1);
		}
		int right(int index)
		{
			return (2*index+2);
		}
};
class p_node
{
  public:
    int cost;
    string to;
    string from;
    p_node* next;
    p_node* prev;
    p_node()
    {
        next = prev = NULL;
    }
    p_node(string to,string from,int cost)
    {
    	this->to = to;
    	this->from = from;
        this->cost = cost;
        next = prev = NULL;
    }
};
class priority_queue
{
    private: 
        p_node* head;
    public:
    	priority_queue(){}
        priority_queue(int)
        {
            p_node* ptr = new p_node;
            cout<<"ENTER THE VERTEX NAME TO WHICH MAKE A LINK : ";
            cin>>ptr->to;
            cout<<"ENTER THE VERTEX NAME FROM WHICH MAKE A LINK : ";
            cin>>ptr->from;
            cout<<"ENTER THE COST : ";
            cin>>ptr->cost;
            head = ptr;
            ptr->next = NULL;
            ptr->prev = NULL;
        }
        priority_queue(string to,string from,int cost)
        {
            p_node* ptr = new p_node;
            ptr->to = to;
            ptr->from = from;
            ptr->cost = cost;
            head = ptr;
            ptr->next = ptr->prev = NULL;
        }
        void enqueue(string to,string from,int cost)
        {
            p_node* ptr = new p_node;
            ptr->to = to;
            ptr->from = from;
            ptr->cost = cost;
            if(head == NULL)
            {
                head = ptr;
                ptr->next = ptr->prev = NULL;
                return;
            }
            p_node* temp2 = NULL;
            p_node* temp1 = head;
            while(temp1 != NULL)
            {
                if(ptr->cost <= temp1->cost)
                {
                    if(temp1->prev == NULL)
                    {
                        p_node* hold = temp1;
                        head = ptr;
                        ptr->next = hold;
                        hold->prev = ptr;
                        ptr->prev = NULL;
                        return;
                    }
                    else
                    {
                        p_node* hold = temp2;
                        temp2->next = ptr;
                        ptr->next =temp1;
                        temp1->prev = ptr;
                        ptr->prev = temp2;
                        return;
                    }
                }
                temp2 = temp1;
                temp1 = temp1->next;
            }
            temp2->next = ptr;
            ptr->next = NULL;
            ptr->prev = temp2;
        }
        int peek()
        {
            p_node* temp = head;
            head = temp->next;
            int x = temp->cost;
            delete temp;
            return x;
        }
        void display()
        {
            p_node* temp = head;
            cout<<endl;
            while(temp != NULL)
            {
                cout<<temp->cost<<" ";
                temp = temp->next;
            }
            cout<<endl;
        }
};
class g_node
{
	public:
		string vertex;
		int visited;
		vector<string> vec;
		g_node* next;
		g_node()
		{
			visited = 0;
			next = NULL;	
		}	
		node(string vertex)
		{
			visited = 0;
			this->vertex = vertex;
		}
};
class graph
{
	private:
		g_node* head;
	public:
		priority_queue p;
		graph()
		{
			head = NULL;
		}
		graph(string ver)
		{
			g_node* ptr = new g_node;
			ptr->vertex = ver;
			ptr->next = NULL;
			head = ptr;
		}
		void dijkstra()
		{
			
		}
		void insert_vertex(string ver)
		{
//			string ver;
//			cout<<"ENTER THE VERTEX NAME : ";
//			cin>>ver;
			g_node* hold = head;
			while(hold != NULL)
			{
				if(hold->vertex == ver)
				{
					cout<<"ALREADY EXIST!"<<endl;
					return;
				}
				hold = hold->next;
			}
			g_node* ptr = new g_node;
			ptr->vertex = ver;
			if(head == NULL)
			{
				ptr->next = NULL;
				head = ptr;
				return;	
			}
			g_node* temp = head;
			while(temp->next != NULL)
			{
				temp = temp->next;
			}
			temp->next = ptr;
			ptr->next = NULL;
		}
		void insert_link(string ver,string linking_vertex)
		{
//			string ver, linking_vertex;
//			cout<<"ENTER VERTEX NAME FROM WHICH A LINK CREATE : ";
//			cin>>ver;
//			cout<<"ENTER VERTEX NAME TO WHICH A LINK CREATE : ";
//			cin>>linking_vertex;
			g_node* temp1 = head;
			while(temp1 != NULL)
			{
				if(temp1->vertex == ver)
				{
					for(int i = 0 ; i < temp1->vec.size();i++)
					{
						if(linking_vertex == temp1->vec[i])
						{
							cout<<"ALREADY LINKED!"<<endl;
							return;
						}
					}
				}
				temp1 = temp1->next;
			}
			temp1 = head;
			while(temp1 != NULL)
			{
				if(temp1->vertex == linking_vertex)
				{
					g_node* temp = head;
					while(temp != NULL)
					{
						if(temp->vertex == ver)
						{
							temp->vec.push_back(linking_vertex);
							sort(temp);
							break;
						}
						temp = temp->next;
					}
					return;
				}
				temp1 = temp1->next;
			}
			cout<<"LINK VERTEX IS NOT FOUND!"<<endl;
		}
		void sort(g_node* temp)
		{
			for(int i = 0; i < temp->vec.size();i++)
			{
				for(int j = 0; j < temp->vec.size();j++)
				{
					if(temp->vec[i] < temp->vec[j])
					{
						string hold = temp->vec[i];
						temp->vec[i] = temp->vec[j];
						temp->vec[j] = hold;  
					}
				}
			}
		}
		void adjacency_list()
		{
			g_node* temp = head;
			while(temp != NULL)
			{
				cout<<temp->vertex<<" -> ";
				for(int i = 0 ;i < temp->vec.size();i++)
				{
					cout<<temp->vec[i]<<" ";
				}
				cout<<endl;
				temp = temp->next;
			}
		}
		void adjacency_matrix()
		{
			g_node* temp = head;
			cout<<"     ";
			while(temp != NULL)
			{
				cout<<temp->vertex<<"   ";
				temp = temp->next;
			}
			cout<<endl;
			temp = head;
			int i = 0,it = 0,j=0;
			g_node* hold = head;
			while(temp != NULL)
			{
				cout<<temp->vertex<<"    ";
				int size = temp->vec.size();
				if(size != 0)
				{
					while(hold != NULL)
					{
						for(j = 0 ; j < size;j++)
						{
							if(hold->vertex == temp->vec[j])
							{
								cout<<"1"<<"   ";
								i = 1;
							}
						}
						if(i != 1)
						{
							cout<<"0"<<"   ";
							it++;
						}
						i = 0;
						hold = hold->next;
					}
					cout<<endl;
				}
				else
				{
					while(hold != NULL)
					{
						cout<<"0"<<"   ";
						hold = hold->next;
					}
				}
				i = 0;
				hold = head;
				temp = temp->next;
			}
			
		}
};
int main()
{
	MinHeap bin(10);
	bin.insert(2);
	bin.insert(4);
	bin.insert(6);
	bin.insert(3);
	bin.insert(7);
	bin.insert(9);
	bin.insert(1);
	bin.insert(12);
	bin.insert(13);
	bin.insert(14);
	bin.display();
	bin.delete_node(1);
	bin.delete_node(9);
	bin.display();
	priority_queue list("A","B",10);
    list.enqueue("A","C",2);
    list.enqueue("B","C",5);
    list.enqueue("E","A",5);
    list.enqueue("D","A",6);
    list.enqueue("D","C",7);
    list.enqueue("C","E",3);
    list.display();
    cout<<"DEQUEUE THE TOP : "<<list.peek();
    list.display();
    graph g;
	g.insert_vertex("A");
	g.insert_vertex("B");
	g.insert_vertex("C");
	g.insert_vertex("D");
	g.insert_vertex("E");
	g.insert_vertex("F");
	g.insert_vertex("G");
	g.insert_vertex("H");
	g.insert_vertex("K");
	
	g.insert_link("A","A");
	g.insert_link("A","D");
	g.insert_link("B","B");
	g.insert_link("B","D");
	g.insert_link("B","K");
	g.insert_link("C","C");
	g.insert_link("C","F");
	g.insert_link("D","A");
	g.insert_link("D","B");
	g.insert_link("D","E");
	g.insert_link("D","G");
	g.insert_link("E","D");
	g.insert_link("E","F");
	g.insert_link("E","G");
	g.insert_link("E","H");
	g.insert_link("F","C");
	g.insert_link("F","E");
	g.insert_link("F","H");
	g.insert_link("F","K");
	g.insert_link("G","D");
	g.insert_link("G","E");
	g.insert_link("G","H");
	g.insert_link("H","E");
	g.insert_link("H","F");
	g.insert_link("H","G");
	g.insert_link("K","F");
	g.insert_link("K","B");
	g.adjacency_list();
	g.adjacency_matrix();
	return 0;
}

