#include<iostream>
using namespace std;
//int find_min_vertex(int* distance,int* visited,int n)
//{
//	//this variable will help us to find the frist moin, then algo will perform accordingly
//	int temp_min = 0;
//	for(int i = 0 ; i < n ; i++)
//	{
//		cout<<"zain";
//		if(visited[i] == 0 || ((distance[i] < distance[temp_min])))
//		{
//			temp_min = i;
//		}
//	}
//	return temp_min;
//}
int find_min_vertex(int *key, bool *mst,int n)
{
	int min = INT_MAX, minIndex;

	for (int i = 0; i < n; i++)
	{
		if (mst[i] == false && key[i] < min)
		{
			min = key[i];
			minIndex = i;
		}
	}
	return minIndex;
}
void dijkstra(int **edge,int n)
{
	int* distance = new int[n];
	bool* visited = new bool[n];
	for(int i = 0 ; i < n ; i++)
	{
		distance[i] = 999;
		visited = false; 
	}
	distance[0] = 0;
	for(int i =0 ; i < n; i++)
	{
		//find the min weight vertex less then the source
		int min_vertex = find_min_vertex(distance,visited,n);
		visited[min_vertex] = true;
		for(int j = 0 ; j < n; j++)
		{
			if(edge[min_vertex][j] != 0 && !visited)
			{
				int dist = distance[min_vertex] + edge[min_vertex][j];
				if(distance[j] > dist)
				{
					distance[j] = dist;
				}
			}
		}
	}
	for(int  i = 0 ; i < n; i++)
	{
		cout<<i<<"\t"<<distance[i]<<endl;
	}

}
int main()
{
	int n = 2 ,e = 1;
	cout<<"ENTER THE NUMBER OF EDGES : ";
//	cin>>e;
	cout<<"ENTER THE NUMBER OF VERTEX : ";
//	cin>>n;
	int** edge = new int*[n];
	for(int i =0 ; i < n;i++)
	{
		edge[i] = new int[n];
		for(int j = 0 ; j < n; j++)
		{
			edge[i][j] = 0;
		}
	}
	for(int i = 0 ; i < n;i++)
	{
		int f,s,weight;
		cout<<"FROM : ";
		cin>>f;
		cout<<"SOURCE : ";
		cin>>s;
		cout<<"WEIGHT : ";
		cin>>weight;	
		edge[f][s] = weight;
		edge[s][f] = weight;
	}
	dijkstra(edge,n);
	return 0;
}

