#include<iostream>
#include<cstdlib>
#include<ctime>
using namespace std;
int partition_by_random_number(int *arr,int l, int r)
{
	int num = rand() % r;
	int pivot = arr[num];
	int i = num;
	for(int j = l ; j < num ; j++)
	{
		if(arr[j] < pivot)
		{
			i++;
			int temp = arr[i];
			arr[i] = arr[j];
			arr[j] = temp;
		}
	}
	cout<<endl<<pivot<<"\t"<<arr[i]<<endl;
	i++;
	int temp = arr[i];
	arr[i] = pivot;
	arr[num] = temp;
	return r;
}
void insertion(int* arr,int n)
{
	for(int i = 1; i < n-1;i++)
	{
		int curr = arr[i];
		int j = i-1;
		while(arr[j]>curr && j>=0)
		{
			arr[j+1] = arr[j];
			j--;
		}
		arr[j+1] = curr;
	}
}
int partition_by_middle_value(int arr[], int left, int right)
{
    int i = left, j = right;
    int tmp;
    int pivot = arr[(left + right) / 2];   
    while (i <= j)
	{
        while (arr[i] < pivot)
        {
            i++;
        }
        while(arr[j] > pivot)
        {
			j--;
		}
        if (i <= j)
		{
        	tmp = arr[i];
            arr[i] = arr[j];
            arr[j] = tmp;
            i++;
            j--;
        }
      };
      return i;
}
int partition_by_frist_value(int *arr,int l, int r)
{
	int frist = l;
	int pivot = arr[frist];
	int i = r;
	for(int j = r ; j < frist ; j++)
	{
		if(arr[j] < pivot)
		{
			int temp = arr[i];
			arr[i] = arr[j];
			arr[j] = temp;
			i--;
		}
	}
	i++;
	int temp = arr[i];
	arr[i] = pivot;
	arr[frist] = temp;
	return r;
}
void quick_sort_by_random_number(int *arr,int l,int r)
{
	if(l<r)
	{
		int pivot = partition_by_random_number(arr,l,r);
		quick_sort_by_random_number(arr,l,pivot-1);
		quick_sort_by_random_number(arr,pivot+1,r);
	}
}
void quick_sort(int *arr,int l,int r)
{
	if(l<r)
	{
		int pivot = partition_by_middle_value(arr,l,r);
		quick_sort(arr,l,pivot-1);
		quick_sort(arr,pivot+1,r);
	}
}
void quick_sort_by_frist_value(int *arr,int l,int r)
{
	if(l<r)
	{
		int pivot = partition_by_frist_value(arr,l,r);
		quick_sort_by_frist_value(arr,l,pivot-1);
		quick_sort_by_frist_value(arr,pivot+1,r);
	}
}
void gen_random(int *arr,int size)
{
	srand(time(0));
	for(int i= 0; i < size ; i++)
	{
		int num = rand() % 100 +1;
		arr[i] = num;
	}
}
int main()
{
	int size = 6;
	cout<<"ENTER THE SIZE OF AN ARRAY : ";
	cin>>size;
	int arr[size];
	int *p = arr;
	gen_random(arr,size);
//	if(size <= 15)
//	{
//		insertion(arr,size);
//		cout<<"NUMBERS ARE : ";
//		for(int i = 0 ; i < size; i++)
//		{
//			cout<<arr[i]<<" ";
//		}
//		exit(-1);
//	}
	cout<<"NUMBERS ARE : ";
	for(int i = 0 ; i < size; i++)
	{
		cout<<arr[i]<<" ";
	}
	quick_sort(arr,0,size);
	cout<<endl<<"SORTED BY MID VALUE; ARRAY NUMBERS ARE : ";
	for(int i = 0 ; i < size; i++)
	{
		cout<<arr[i]<<" ";
	}
	quick_sort_by_frist_value(arr,0,size);
	cout<<endl<<"SORTED BY FRIST VALUE; ARRAY NUMBERS ARE : ";
	for(int i = 0 ; i < size; i++)
	{
		cout<<arr[i]<<" ";
	}
	cout<<endl;
	quick_sort_by_frist_value(arr,0,size);
	cout<<endl<<"SORTED BY FRIST VALUE; ARRAY NUMBERS ARE : ";
	for(int i = 0 ; i < size; i++)
	{
		cout<<arr[i]<<" ";
	}
	cout<<endl;(arr,0,size);
	cout<<endl<<"SORTED BY RANDOM VALUE; ARRAY NUMBERS ARE : ";
	for(int i = 0 ; i < size; i++)
	{
		cout<<arr[i]<<" ";
	}
	cout<<endl;
	if(size%2 == 0)
	{
		cout<<endl<<"MEDIAN OF THE ARRAY IS :--- "<<arr[(size/2)-1]<<" and "<<arr[size/2]<<endl;
	}
	else
	{
		cout<<"MEDIAN OF THE ARRAY IS : "<<arr[size/2]<<endl;	
	}
	delete p;
	return 0;
}





