#include<iostream>
using namespace std;
void merge(int* arr,int l,int mid,int r)
{
	int x = mid - l +1;
	int y = r - mid;
	int a[x],b[y];
	for(int i = 0 ; i < x; i++)
	{
		a[i] = arr[l+i];
	}
	for(int i = 0 ; i < y; i++)
	{
		b[i] = arr[mid+i+1];
	}
	int i = 0, j = 0, k = l;
	while(i < x && j < y)
	{
		if(a[i] >= b[j])
		{
			arr[k] = b[j];
			j++;k++;
		}
		else
		{
			arr[k] = a[i];
			i++;k++;
		}
	}
	while(i < x)
	{
		arr[k] = a[i];
		i++;k++;
	}
	while(j < y)
	{
		arr[k] = b[j];
		j++;k++;
	}
}
void merge_sort(int *arr,int l,int r)
{
	if(l < r)
	{
		int mid = (l+r)/2;
		merge_sort(arr,l,mid);
		merge_sort(arr,mid+1,r);
		merge(arr,l,mid,r);
	}
}
int main()
{
	int arr[10] = {10,9,8,7,6,5,4,3,2,1};
	merge_sort(arr,0,9);
		for(int i = 0; i < 10;i++)
		{
			cout<<arr[i]<<" ";
		}
		cout<<endl;
	return 0;
}

