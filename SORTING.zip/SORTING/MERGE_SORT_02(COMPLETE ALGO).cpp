#include<iostream>
using namespace std;
void merge(int arr[],int l,int mid,int r)
{
    int x = mid - l + 1;
    int y = r - mid;
	int a[x],b[y];
	cout<<"start : "<<l<<" "<<"stop : "<<r<<" "<<"left : "<<x<<" "<<"mid : "<<mid<<" "<<"right : "<<y<<endl;
	    for(int i = 0 ; i < x ; i++)
	    {
	        a[i] = arr[l+i];
	    }
	    for(int  j = 0 ; j < y ; j++)
	    {
	        b[j] = arr[mid+j+1];
	    }
	    
	    for(int i = 0 ; i < x; i++)
	    {
	        cout<<a[i]<<" ";
	    }
	    cout<<endl;
	    for(int i = 0 ; i < y; i++)
	    {
	        cout<<b[i]<<" ";
	    }
	    cout<<endl;
	        int  i = 0 , j = 0, k = l;
	        while(i < x && j < y)
	        {
	            if(a[i]<=b[j])
	            {
	                arr[k] = a[i];
	                i++;k++;
	            }
	            else
	            {
	                arr[k] = b[j];
	                j++;k++;
	            }
	        }
	        
	        while(i < x)
            {
                arr[k] = a[i];
                k++;i++;
            }
            while(j < y)
            {
                arr[k] = b[j];
                k++;j++;
            }
	    for(int i = 0 ; i < 12; i++)
	    {
	        cout<<arr[i]<<" ";
	    }
	    cout<<endl;
	int p;
	cin>>p;
}
void merge_sort(int arr[],int l,int r)
{
    if(l<r)
    {
        int mid = (l+r)/2;
        cout<<"start : "<<l<<" "<<" "<<"mid : "<<mid<<" "<<"stop : "<<r<<endl;
        merge_sort(arr,l,mid);
        cout<<"THIS COMPLETE"<<endl;
        cout<<"start : "<<mid+1<<" "<<" "<<"mid : "<<mid<<" "<<"stop : "<<r<<endl;
        merge_sort(arr,mid+1,r);
        cout<<"ME ALSO"<<endl;
        cout<<"start : "<<l<<" "<<" "<<"mid : "<<mid<<" "<<"stop : "<<r<<endl;
        merge(arr,l,mid,r);
        cout<<"ME MERGE"<<endl;
    }
    cout<<"ME BREAK"<<endl;
}
int main()
{
	int arr[12] = {12,11,10,9,8,7,6,5,4,3,2,1};
//	int arr[12] = {6,7,8,9,10,11,0,1,2,3,4,5};
// 	cout<<sizeof(arr)/(sizeof(arr[0]));
	merge_sort(arr,0,11);
	for(int i = 0 ; i < 12 ; i++)
	{
		cout<<arr[i]<<" ";
	}
	return 0;
}

