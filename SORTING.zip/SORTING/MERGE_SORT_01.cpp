#include<iostream>
using namespace std;
void merge(int arr[],int size)
{
	int mid  = size/2;
	
	for(int i = 0,j = mid+1; i < mid || j < size ; )
	{
		if(arr[i] > arr[j])
		{
			int temp = arr[i];
			arr[i] = arr[j];
			arr[j]= temp;
			i++;
		}
		if(arr[j] > arr[i])
		{
			int temp = arr[j];
			arr[j] = arr[i];
			arr[i]= temp;
			j++;
		}
	}
	
}
int main()
{
	int arr[10] = {5,4,3,2,6,7,1,8,0,9};
	merge(arr,10);
	for(int i = 0 ; i < 10 ; i++)
	{
		cout<<arr[i]<<" ";
	}
	return 0;
}

