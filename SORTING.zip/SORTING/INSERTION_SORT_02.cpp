#include<iostream>
using namespace std;
void insertion(int *arr,int size)
{
	int temp,x,hold;
	for(int  i = 1 ; i < size; i++)
	{
		hold = arr[i];
		x = i;
		for(int j = i ; j >= 0; j--)
		{
			if(hold < arr[j])
			{
				int temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
				i--;
			}
		}
		i = x;
	}
}
int main()
{
	int arr[10] = {10,9,8,7,6,5,4,3,2,1};
	insertion(arr,10);
		for(int i = 0; i < 10;i++)
		{
			cout<<arr[i]<<" ";
		}
		cout<<endl;
	return 0;
}

