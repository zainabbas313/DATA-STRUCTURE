#include<iostream>
using namespace std;
class date
{
    private:
        int day[5],year[5],month[5];
    public:
        date()
        {

        }
        date(int day, int year, int month)
        {
            this->day[0] = day;
            this->year[0] = year;
            this->month[0] = month;
        }
        void set_date()
        {
            for(int i = 0; i<5 ;i++)
            {
                cout<<"DAY : ";
                cin>>day[i];
                cout<<"MONTH : ";
                cin>>month[i];
                cout<<"YEAR : ";
                cin>>year[i];
            }
        }
        void sort()
        {
            for(int i = 0; i < 4; i++)
            {
                for(int j = i+1; j < 5; j++)
                {
                    if(year[i]>year[j])
                    {
                        int temp = year[i];
                        year[i] = year[j];
                        year[j] = temp;
                        temp = month[i];
                        month[i] = month[j];
                        month[j] = temp;
                        temp = day[i];
                        day[i] = day[j];
                        day[j] = temp;
                    }
                }
            }
        }
        
        void get()
        {
            cout<<"DAY"<<" / "<<"month"<<" / "<<"year"<<endl;
            for(int i = 0 ; i < 5 ; i++)
            {
                cout<<day[i]<<" / "<<month[i]<<" / "<<year[i]<<endl;
            }
        }
};
int main()
{
    date obj;
    obj.set_date();
    obj.sort();
    obj.get();
}



