#include<iostream>
using namespace std;
void swap(int *x,int *y)
{
	int *temp = x;
	*x = *y;
	*y = *temp;
}
void selection(int *arr,int size)
{
	
	int temp,x = 0;
	for(int i = 0 ; i < size; i++)
	{
		int min = arr[i];
		for(int j = i+1 ; j < size; j++)
		{
			if(min > arr[j])
			{
				min = arr[j];
				x = j;
			}
		}
		if(x != 0)
		{
			temp = arr[i];
			arr[i]= arr[x];
			arr[x] = temp;
		}
		x =0 ;
	}
}
int main()
{
	int arr[10] = {10,9,8,7,6,5,4,3,2,1};
	selection(arr,10);
	for(int i = 0 ; i < 10;i++)
	{
			cout<<arr[i]<<" ";
	}
	return 0;
}

