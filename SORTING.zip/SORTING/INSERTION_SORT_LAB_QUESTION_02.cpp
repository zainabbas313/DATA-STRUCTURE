#include<iostream>
using namespace std;
void insert_sort(int * arr,int n)
{
    for(int  i =0 ; i < n-1 ;i++)
    {
        int cur = arr[i];
        int  j = i-1;
        while(arr[j]>cur && j>=0)
        {
            arr[j+1] = arr[j];
            j--;
        }
        arr[j+1] = cur;
    }
}
int main()
{
    int size;
    cout<<"ENTER THE SIZE OF AN ARRAY : ";
    cin>>size;
    int * arr = new int[size];
    cout<<"ENTER THE PRICE OF THE TOYS"<<endl;
    for(int i = 0 ; i < size ; i++)
    {
        cout<<"toy # "<<i+1<<" : ";
        cin>>arr[i];
        cout<<endl;
    }
    insert_sort(arr,size);
    int amount;
    cout<<"ENTER THE AMOUNT DO WE HAVE : ";
    cin>>amount;
    cout<<"WE CAN BUY THE TOYS OF PRICES : ";
    for(int i = 0 ; i < size ; i++)
    {
        if(arr[i] <= amount)
        {
            cout<<arr[i]<<" ";
        }
    }
}
