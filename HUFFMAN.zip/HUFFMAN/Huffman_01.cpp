#include<iostream>
using namespace std;
class q_node
{
	public:
		int frequency;
		string vertex_name;
		q_node* next;
		q_node* prev;
		q_node()
		{
			next = prev = NULL;
		}
		q_node(string vertex_name,int frequency)
		{
			this->frequency = frequency;
			this->vertex_name = vertex_name;
			next = prev = NULL;
		}
};
class PriorityQueue
{
	private:
		q_node* head;
	public:
		PriorityQueue()
		{
			head = NULL;
		}
		PriorityQueue(string ver,int fre)
		{
			q_node* ptr = new q_node;
			ptr->frequency = fre;
			ptr->vertex_name = ver;
			ptr->next = NULL;
			ptr->prev = NULL;
			head = ptr;
		}
		void enqueue(string ver,int fre)
		{
			q_node* ptr = new q_node;
			ptr->frequency = fre;
			ptr->vertex_name = ver;
			if(head == NULL)
			{
				ptr->next = ptr->prev = NULL;
				head = ptr;
				return;
			}
			q_node* temp = head;
			q_node* hold = head;
			while(temp != NULL)
			{
				if(temp->frequency <= fre)
				{
					if(temp->prev == NULL)
					{
						temp->prev = ptr;
						ptr->next = temp;
						ptr->prev = NULL;
						head = ptr;
						return;
					}
					hold->next = ptr;
					temp->prev = ptr;
					ptr->prev = hold;
					ptr->next = temp;
					return;
				}
				hold = temp;
				temp = temp->next;
			}
			hold->next = ptr;
			ptr->next = NULL;
			ptr->prev = hold;
		}
		q_node* dequeue()
		{
			if(head == NULL)
			{
				cout<<"QUEUE IS EMPTY!"<<endl;
			}
			else
			{
				q_node* temp = head;
				int x = temp->frequency;
				head  = head->next;
				return temp;
			}
		}
		bool IsEmpty()
		{
			if(head == NULL)
			{
				return true;
			}
			return false;
		}
		void display()
		{
			q_node* temp = head;
			while(temp != NULL)
			{
				cout<<temp->frequency<<" "<<temp->vertex_name<<endl;
				temp = temp->next;
			}
			cout<<endl;
		}		
};
class h_node
{
	public:
		int bits;
		string vertex_name;
		int frequency;
		h_node* left;
		h_node* right;
		h_node()
		{
			bits = 0;
			left = right = NULL;
		}
		h_node(string vertex_name,int frequency)
		{
			this->frequency = frequency;
			this->vertex_name = vertex_name;
			left = right = NULL;
		}
};
class Huffman
{
	private:
		h_node* root;
	public:
		Huffman()
		{
			root = NULL;
		}
		Huffman(string ver,int fre)
		{
			h_node* ptr = new h_node;
			ptr->frequency = fre;
			ptr->vertex_name = ver;
			root = ptr;
		}
		void insert(string ver,int fre)
		{
			h_node* ptr = new h_node;
			ptr->frequency = fre;
			ptr->vertex_name = ver;
			if(root == NULL)
			{
				root = ptr;
				return;
			}
			h_node* temp = root;
			insertion(temp,ptr);
		}
		h_node* insertion(h_node* temp,h_node* ptr)
		{
			if(temp == NULL)
			{
				temp = ptr;
				return ptr;
			}
			if(temp->frequency >= ptr->frequency)
			{
				temp->left = insertion(temp->left,ptr);
				temp->bits = 0;
			}
			else
			{
				temp->right = insertion(temp->right,ptr);
				temp->bits = 0;
			}
			return temp;
		}
		void display()
		{
			if(root == NULL)
			{
				cout<<"IT IS EMPTY!"<<endl;
				return;
			}
			h_node* temp = root;
			post_order(temp);
		}
		void post_order(h_node* temp)
		{
			if(temp != NULL)
			{
				post_order(temp->left);
				cout<<temp->frequency<<"  ";
				post_order(temp->right);
			}
		}
};
int main()
{
	PriorityQueue list;
    Huffman list1;
    string ver[6] = {"F","E","D","B","C","A"};
    int freq[6] =   {2 , 3 , 5, 10, 30, 50};
    list1.insert(ver[0],freq[0]);
    for(int i = 0, j = 1; i < 6 ;i++,j++ )
    {
    	list1.insert(ver[j],freq[j]);
    	list1.insert("",freq[i]+freq[j]);
    	cout<<"zain";
	}
    list1.display();
//    for(int i = 0 ; i < 6 ; i++)
//    {
//    	q_node* temp = list.dequeue();
//    	list1.insert(temp->vertex_name,temp->frequency);
//	}
//    list1.display();
	return 0;
}

