#include<iostream>
using namespace std;
class node
{
    public:
        int data;
        int key;
        node * next;
        node * prev;
        node()
        {
            next = NULL;
            prev = NULL;
        }
        node(int data, int key)
        {
            this->data = data;
            this->key = key;
            next = NULL;
            prev = NULL;
        }
        ~node()
        {
            delete next;
            delete prev;
            next = prev = NULL;
        }
};
class dllnode
{
    public:
        node*head;
        node*tail;
        dllnode()
        {
            head = NULL;
            tail = NULL;
        }
        dllnode(int val, int k)
        {
            node * ptr  = new node;
            head = tail = ptr;
            ptr->next = ptr->prev = NULL;
            ptr->data = val;
            ptr->key = k;
        }
        void insert_at_end(int val,int k)
        {
            node*ptr = new node;
                if(head == NULL && tail == NULL )
                {
                    head = tail = ptr;
                    ptr->next = ptr->prev = NULL;
                    ptr->data = val;
                    ptr->key = k;
                }
                else
                {
                    node* temp = head;
                    while(temp->next != NULL)
                    {
                        temp = temp->next;
                    }
                    temp->next = ptr;
                    ptr->next = NULL;
                    ptr->prev = temp;
                    ptr->data = val;
                    ptr->key = k;
                    tail = ptr;
                }
        }
        void insert_at_beg(int val,int k)
        {
            node* ptr = new node;
            if(head == NULL && tail == NULL)
            {
                head = tail = ptr;
                ptr->data = val;
                ptr->key = k;
                ptr->next = ptr->prev = NULL;
            }
            else
            {
                node*temp = head;
                head = ptr;
                ptr->next = temp;
                ptr->prev = NULL;
                ptr->data = val;
                ptr->key = k;
            }
        }
        void delete_of_end()
        {
            if(head == NULL && tail == NULL)
            {
                cout<<"LIST DOES NOT EXIST"<<endl;
            }
            else
            {
                node*temp = head;
                node*before_temp = head;
                if(temp->next == NULL && temp->prev == NULL)
                {
                    head = tail = NULL;
                    delete temp;
                    delete before_temp;
                    temp = before_temp = NULL;
                    return;
                }
                while(temp->next != NULL)
                {
                    before_temp = temp;
                    temp = temp->next;
                }
                before_temp->next = NULL;
                temp->prev = NULL;
                delete temp;
                temp = NULL;
            }
        }
        
        void print_by_head()
        {
            node*temp = head;
            if(head == NULL)
            {
                cout<<"LIST DOES NOT EXIST"<<endl;
                return;
            }
            while(temp != NULL)
            {
                cout<<"data : "<<temp->data<<" "<<"key : "<<temp->key<<endl;
                temp = temp->next;
            }
        }
        void print_by_tail()
        {
            node*temp = tail;
            while(temp != NULL)
            {
                cout<<"data : "<<temp->data<<" "<<"key : "<<temp->key<<endl;
                temp = temp->prev;
            }
        }
        void node_swap()
        {
        	node *t = head;
        	node *t1 = head->next;
        	node *r = tail;
        	node *r1 = tail->prev;
        			t1->prev = r;
        			r->prev = NULL;
        			t->next = NULL;
        			t->prev = r1;
        			r1->next = t;
        			r->next = t1;
        			head = r;
					tail = t;
					t = head->next;
        			t1 = t->next;
        			r = tail->prev;
        			r1 = r->prev;
        	while((t->prev != r && r->next != t))
        	{
				cout<<"Zain"<<endl;
				node * hold1 = t1;
				node * hold2 = r1;
				t->next = r1;
				t1->next = r;
				t1->prev = hold2->prev;
				r->prev = t1;
				r->next = hold1->next;
				r1->next = t1;
				t = t1;
				t1 = t1->next;
				r = r1;
				r1 = r1->prev;
			}
		
		}
};
int main()
{
    dllnode list(1,1);
    list.insert_at_end(2,2);
    list.insert_at_end(3,3);
    list.insert_at_end(4,4);
    list.print_by_head();
	cout<<"................."<<endl;
	list.node_swap();
	list.print_by_head();
	cout<<endl;
    return 0;
}



