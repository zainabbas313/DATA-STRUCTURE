#include<iostream>
#include<cstdlib>
using namespace std;
template<typename T>
class node
{
    public:
        T data;
        T key;
        node<T> *next;
        node<T> *prev;
        node(T data, int key)
        {
            this->data =data;
            this->key = key;
            next = NULL;
            prev = NULL;
        }
        node()
        {
            next = prev = NULL;
        }
};
template<class T>
class dllnode
{
        public:
            node<T>* head;
            node<T>* tail;
            dllnode()
            {
                head = tail = NULL;
            }
            dllnode(T val,int k)
            {
                node<T> * ptr = new node<T>;
                ptr->data = val;
                ptr->key  = k;
                ptr->next = ptr->prev = NULL;
                head = tail = ptr;
            }
            void insert_at_end(T val, int k)
            {
                node<T>* ptr = new node<T>;
                ptr->data = val;
                ptr->key = k;
                if(head == NULL && tail == NULL)
                {
                    head = tail = ptr;
                    ptr->next= ptr->prev = NULL;
                    return;
                }
                node<T>*temp = head;
                while(temp->next != NULL)
                {
                    temp = temp->next;
                }
                temp->next = ptr;
                ptr->next = NULL;
                ptr->prev = temp;
                tail = ptr;
            }
            void print()
            {
                node<T>* temp = head;
                if(head == NULL)
                {
                    cout<<"LIST DOES NOT EXIST"<<endl;
                }
                else
                {
                    while(temp->next != head)
                    {
                        cout<<"data : "<<temp->data<<" "<<"key : " << temp->key<<endl;
                        temp = temp->next;
                    }
                }
            }
};
int main()
{
    dllnode<double>list(1.2,1);
    list.insert_at_end(12.2,3);
    list.print();
}
