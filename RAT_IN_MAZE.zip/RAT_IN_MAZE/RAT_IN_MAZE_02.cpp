#include<iostream>
using namespace std;
bool is_safe(int ** array,int x,int y,int size)
{
	if(x<size && y<size && array[x][y] == 1)
	{
		return true;
	}
	return false;
}

bool rat_in_maze(int** array,int x,int y,int size,int** path_array)
{
	if(x == size-1 && y == size-1)
	{
		path_array[x][y] = 2;
		return true;
	}
	if(is_safe(array,x,y,size))
	{
		path_array[x][y] = 2;
		if(rat_in_maze(array,x+1,y,size,path_array))
		{
			return true;
		}
		if(rat_in_maze(array,x,y+1,size,path_array))
		{
			return true;
		}
		path_array[x][y] = 0;
		return false;		
	}
	return false;
	
}
int main()
{
	int size;
	cout<<"ENTER THE SIZE OF AN ARRAY : ";
	cin>>size;
	int** array = new int*[size];
	int** path_array = new int*[size];
		for(int i = 0; i<size; i++)
		{
			array[i] = new int[size];
		}
		for(int i = 0; i<size; i++)
		{
			path_array[i] = new int[size];
		}
		cout<<"ENTER THE MAZE PATHS AS 1 AND BLOCK AS 0 ";
		for(int  i = 0 ; i < size; i++)
		{
			for(int  j = 0 ; j < size; j++)
			{
				cin>>array[i][j];
			}
		}
		for(int  i = 0 ; i < size; i++)
		{
			for(int  j = 0 ; j < size; j++)
			{
				path_array[i][j] = 0;
			}
		}
		cout<<"THE MAZE"<<endl;
		for(int  i = 0 ; i < size; i++)
		{
			for(int  j = 0 ; j < size; j++)
			{
				cout<<array[i][j]<<" ";
			}
			cout<<endl;
		}
		
		rat_in_maze(array,0,0,size,path_array);
		
		cout<<"THE PATH THAT FOLLOWED BY RAT"<<endl;
		for(int  i = 0 ; i < size; i++)
		{
			for(int  j = 0 ; j < size; j++)
			{
				cout<<path_array[i][j]<<" ";
			}
			cout<<endl;
		}
	return 0;
}

//1 0 0 1 0 
//1 1 0 0 1
//1 1 1 1 0
//0 1 1 1 1
//0 0 1 0 1











