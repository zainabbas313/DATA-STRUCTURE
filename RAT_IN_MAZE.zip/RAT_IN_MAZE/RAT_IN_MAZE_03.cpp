#include<iostream>
using namespace std;
int is_safe(int** arr, int x, int y,int nx,int ny)
{
    if(x < nx && y < ny && arr[x][y] == 1)
    {
        return true;
    }
        return false;
}
int rat_in_maze(int** arr,int x, int y, int nx,int ny, int** sol_arr)
{
    if(x == (nx-1) &&  y == (ny-1))
    {
    	sol_arr[x][y] = 1;
        return true;
    }
    if(is_safe(arr,x+1,y,nx,ny))
    {
//    	cout<<"zainx";
        sol_arr[x+1][y] = 1;
        if(rat_in_maze(arr,x+1,y,nx,ny,sol_arr))
        {
            return true;
        }
        sol_arr[x][y] = 0;
        return false;
    }
    if(is_safe(arr,x,y+1,nx,ny))
    {
//    	cout<<"zainy";
        sol_arr[x][y+1] = 1;
        if(rat_in_maze(arr,x,y+1,nx,ny,sol_arr))
        {
            return true;
        }
        sol_arr[x][y] = 0;
        return false;
    }
    if(is_safe(arr,x-1,y,nx,ny))
    {
//    	cout<<"zainy";
        sol_arr[x-1][y] = 1;
        if(rat_in_maze(arr,x-1,y,nx,ny,sol_arr))
        {
            return true;
        }
        sol_arr[x][y] = 0;
        return false;
    }
    if(is_safe(arr,x,y-1,nx,ny))
    {
//    	cout<<"zainy";
        sol_arr[x][y-1] = 1;
        if(rat_in_maze(arr,x,y-1,nx,ny,sol_arr))
        {
            return true;
        }
        sol_arr[x][y] = 0;
        return false;
    }
}
int main()
{
    int** arr = new int*[4];
	int** path_array = new int*[4];
		for(int i = 0; i<4; i++)
		{
			arr[i] = new int[5];
		}
		for(int i = 0; i<4; i++)
		{
			path_array[i] = new int[5];
		}
		for(int i = 0; i < 4; i++)
        {
            for(int j = 0 ; j < 5; j++)
            {
                cin>>arr[i][j];
            }
        }
		for(int i = 0; i < 4; i++)
        {
            for(int j = 0 ; j < 5; j++)
            {
                path_array[i][j] = 0;
            }
        }
		
		
            rat_in_maze(arr,0,0,4,5,path_array);  
            
        for(int i = 0; i < 4; i++)
        {
            for(int j = 0 ; j < 5; j++)
            {
                cout<<path_array[i][j]<<" ";
            }
            cout<<endl;
        }
}

//1 0 1 1 1
//1 0 1 0 1
//1 0 1 0 1
//1 1 1 0 1








