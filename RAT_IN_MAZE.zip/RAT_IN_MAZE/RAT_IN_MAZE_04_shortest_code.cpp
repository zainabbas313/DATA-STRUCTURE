#include<iostream>
using namespace std;
int is_safe(int** arr, int x, int y,int n)
{
    if(x < n && y < n && arr[x][y] == 1)
    {
        return true;
    }
        return false;
}
int rat_in_maze(int** arr,int x, int y, int n, int** sol_arr)
{
    sol_arr[x][y] = 2;
    if(x == (n-1) &&  y == (n-1)){
        return true;
    }
    
    if(is_safe(arr,x+1,y,n))
    {
        if(rat_in_maze(arr,x+1,y,n,sol_arr))
        {
            return true;
        }
        sol_arr[x][y] = 0;
        return false;
    }
    if(is_safe(arr,x,y+1,n))
    {
        if(rat_in_maze(arr,x,y+1,n,sol_arr))
        {
            return true;
        }
        sol_arr[x][y] = 0;
        return false;
        
    }
    return false;
}
int main()
{
	int size;
	cout << "RAT IN A MAZE" <<endl;
	cout << "ENTER THE SIZE FOR MAZE : ";
	cin >> size;
    int** arr = new int*[size];
	int** path_array = new int*[size];
		for(int i = 0; i<size; i++)
		{
			arr[i] = new int[size];
		}
		for(int i = 0; i<size; i++)
		{
			path_array[i] = new int[size];
		}
		cout << "ENTER THE PATH [1 => BLOCK / 0 => WAY] " <<endl;
		for(int i = 0; i < size; i++)
        {
        	cout << "ENTER THE PATH OF ROW " << i << " : ";
            for(int j = 0 ; j < size; j++)
            {
                cin>>arr[i][j];
            }
            cout << endl ;
        }
        cout<< "THE MAZE" <<endl;
        for(int i = 0; i < size; i++)
        {
            for(int j = 0 ; j < size; j++)
            {
                cout << arr[i][j] << " ";
            }
            cout << endl;
        }
		for(int i = 0; i < size; i++)
        {
            for(int j = 0 ; j < size; j++)
            {
                path_array[i][j] = 0;
            }
        }
		
		
            rat_in_maze(arr,0,0,size,path_array);  
        cout << "THE PATH RAT FOLLOWED" <<endl;
        for(int i = 0; i < size; i++)
        {
            for(int j = 0 ; j < size; j++)
            {
                cout<<path_array[i][j]<<" ";
            }
            cout<<endl;
        }
}










