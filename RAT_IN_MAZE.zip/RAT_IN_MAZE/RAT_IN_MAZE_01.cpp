#include<iostream>
using namespace std;
int is_safe(int** arr, int x, int y,int n)
{
    if(x < n && y < n && arr[x][y] == 1)
    {
        return true;
    }
        return false;
}
int rat_in_maze(int** arr,int x, int y, int n, int** sol_arr)
{
    if(x == (n-1) &&  y == (n-1))
    {
        sol_arr[x][y] = 1;
        return true;
    }
    if(is_safe(arr,x,y,n))
    {
        sol_arr[x][y] = 1;
    }
    if(is_safe(arr,x+1,y,n))
    {
        // sol_arr[x+1][y] = 1;
        if(rat_in_maze(arr,x+1,y,n,sol_arr))
        {
            return true;
        }
        sol_arr[x][y] = 0;
        return false;
    }
    if(is_safe(arr,x,y+1,n))
    {
        sol_arr[x][y+1] = 1;
        if(rat_in_maze(arr,x,y+1,n,sol_arr))
        {
            return true;
        }
        sol_arr[x][y] = 0;
        return false;
        
    }
    return false;
}
int main()
{
    int** arr = new int*[3];
	int** path_array = new int*[3];
		for(int i = 0; i<3; i++)
		{
			arr[i] = new int[3];
		}
		for(int i = 0; i<3; i++)
		{
			path_array[i] = new int[3];
		}
		for(int i = 0; i < 3; i++)
        {
            for(int j = 0 ; j < 3; j++)
            {
                cin>>arr[i][j];
            }
        }
		for(int i = 0; i < 3; i++)
        {
            for(int j = 0 ; j < 3; j++)
            {
                path_array[i][j] = 0;
            }
        }
		
		
            rat_in_maze(arr,0,0,3,path_array);  
            
        for(int i = 0; i < 3; i++)
        {
            for(int j = 0 ; j < 3; j++)
            {
                cout<<path_array[i][j]<<" ";
            }
            cout<<endl;
        }
}










