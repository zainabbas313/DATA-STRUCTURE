#include<iostream>
#include<vector>
using namespace std;
vector<vector<int>> vec;
int main()
{
	cout<<"ENTER THE NUMBER VERTEX : ";
	int n;cin>>n;
	cout<<"ENTER THE NUMBER EDGES : ";
	int m;cin>>m;
	int w,u,v;
	for(int  i = 0 ; i < m;i++)
	{
		cin>>w>>u>>v;
		vec.push_back({w,u,v});
	}
	for(auto i : vec)
	{
		int w = i[0];
		int u = i[1];
		int v = i[2];
		cout<<w<<" "<<u<<" "<<v<<endl;
	}
	for(auto i: vec)
	{
		int v = i[1];
		for(auto i: vec)
		{
			int u = j[1];
			cout<<v<<" "<<u<<endl;
		}
	}

	return 0;
}

