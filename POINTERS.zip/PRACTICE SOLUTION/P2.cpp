#include<iostream>
using namespace std;
class stackQ
{
	public:
		int top,front,rear,size;
		string *arr;
		stackQ()
		{
			top = front = rear = size = 0;
		}
		stackQ(int size)
		{
			this->size = size;
			arr = new string[size];
			top = 0;
			front = rear = size;
		}
		void push(string val)
		{
			if(top == size)
			{
				cout<<"stackQ is overflow!"<<endl;
				return;
			}
			if( top != rear)
			{
				arr[top] = val;
				top++;
				return;
			}
			cout<<"already filled!"<<endl;
		}
		string pop()
		{
			if(rear != 0)
			{
				top--;
				return arr[top];
			}
			cout<<"stack is empty"<<endl;
		}
		void enqueue(string val)
		{
			if(rear == 0)
			{
				cout<<"Queue overflow"<<endl;
				return;
			}
			if(rear == top)
			{
				cout<<"already occuppied!"<<endl;
				return;
			}
			rear--;
			arr[rear] = val;
		}
		string dequeue()
		{
			if(rear == size)
			{
				string x = arr[rear];
				rear++;
				return x;
			}
			cout<<"queue is empty"<<endl;
		}
		void display()
		{
			cout<<"stack : ";
			for(int i = top-1; i >= 0 ;i--)
			{
				cout<<arr[i]<<" ";
			}
			cout<<endl<<"queue : ";
			for(int i = front-1 ; i >= rear; i--)
			{
				cout<<arr[i]<<" ";
			}
		}
};
int main()
{
	stackQ l(10);
	l.push("A");
	l.push("B");
	l.push("C");
	l.push("D");
	l.push("E");
	l.push("F");
	l.enqueue("A");
	l.enqueue("B");
	l.enqueue("C");
	l.enqueue("D");
	l.enqueue("E");
	l.enqueue("F");
	l.display();
	return 0;
}

