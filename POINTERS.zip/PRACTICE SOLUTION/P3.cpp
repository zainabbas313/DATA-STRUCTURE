#include<iostream>
using namespace std;
class array
{
	public:
		int s,f;
		array(){}
		array(int s,int f)
		{
			this->s = s;
			this->f = f;	
		}	
};
void selection(int *arr,int size,int *sort)
{
	
	int temp,x = 0;
	for(int i = 0 ; i < size; i++)
	{
		for(int j = 0 ; j < size; j++)
		{
			if(arr[i] == arr[j])
			{
				cout<<arr[i]<<" "<<arr[j]<<endl;
				sort[x] = j;
				x++;
			}
		}
	}
	cout<<endl;
	for(int i = 0 ; i < size ; i++)
	{
		cout<<sort[i]<<" ";
	}
}
int main()
{
	int size;
	cout<<"ENTER THE SIZE OF AN ARRAY : ";
	cin>>size;
	array *arr = new array[size];
	int s,f;
	for(int i = 0; i < size;i++)
	{
		cin>>s>>f;
		arr[i].s = s;
		arr[i].f = f;
	}
	int time_interval[size];
	for(int  i = 0 ; i < size ; i++)
	{
		time_interval[i] = arr[i].f - arr[i].s;
		cout<<time_interval[i]<<" ";
	}
	cout<<endl;
	int sort[size];
	selection(time_interval,size,sort);
	cout<<endl;
	for(int i = 0; i < size; i++)
	{
		cout<<time_interval[i]<<"  "<<sort[i]<<endl;
	}
	return 0;
}











