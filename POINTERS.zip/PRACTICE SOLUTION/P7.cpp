#include <iostream>
#include<vector>
const int table_size = 200;
using namespace std;
class HashTableEntry
 {
	public:
		int v, k;
		HashTableEntry *next;
		HashTableEntry()
		{
    		next = NULL;
		}	
		HashTableEntry(int k, int v)
		{
      		this->k = k;
      		this->v = v;
      		this->next = NULL;
   		}
};
class HashMapTable
{
	public:
    	HashTableEntry **ht;
    	HashMapTable()
		{
    		ht = new HashTableEntry*[table_size];
			for (int i = 0; i < table_size; i++)
			{
        	    ht[i] = NULL;
			}
    	}
      //TASK_01
      	int HashFunc(int key)
		{
        	 return key % table_size;
      	}
      	void Insert(int k, int v)
	   	{
        	int hash_v = HashFunc(k);
        	HashTableEntry* ptr = ht[hash_v];
         	HashTableEntry* temp = NULL;
         	while(ptr != NULL) 
		 	{
        		temp = ptr;
        		ptr = ptr->next;
         	}
            ptr = new HashTableEntry;
			ptr->k = k;
			ptr->v = v;
            if(temp == NULL)
			{
            	ht[hash_v] = ptr;
           	}
			else 
			{
            	temp->next = ptr;
            }
      	}
      	void Remove(int k)
	   	{
        	int hash_v = HashFunc(k);
         	HashTableEntry* ptr = ht[hash_v];
         	HashTableEntry* temp = NULL;
         	if(ptr == NULL)
			{	
            	cout<<"KEY DOES NOT FOUND"<<k<<endl;
            	return;
        	}
         	while (ptr->next != NULL) 
		 	{
         	   temp = ptr;
         	   ptr = ptr->next;
         	}
         	if(temp != NULL)
			{
            	temp->next = ptr->next;
         	}
         	delete ptr;
         	cout<<"SUCCESSFULLY DELETED!"<<endl;
      	}
      	void SearchKey(int k)
		{
        	int hash_v = HashFunc(k);
         	bool flag = false;
         	HashTableEntry* ptr = ht[hash_v];
         	if (ptr != NULL)
		  	{
            	while (ptr != NULL)
				{
               		if (ptr->k == k) 
			   		{
                		flag = true;
               		}	
               		if(flag)
			    	{
                  		cout<<"ELEMENT OF KEY : "<<k<<endl;
                  		cout<<"VALUE AT THAT KEY : "<<ptr->v<<endl<<endl;
               		}
               		ptr = ptr->next;
           		 }
         	}
         	if(!flag)
         	{
           		cout<<"KEY DOES NOT FOUND "<<k<<endl;
		 	}
      	}
};
int main()
{
	HashMapTable t;
	t.Insert(1,345);
	t.Insert(2,567);
	t.Insert(5,2132);
	t.Insert(5,23523);
	t.Insert(3232,553);
	t.SearchKey(5);
	t.SearchKey(1);
	t.SearchKey(2);
	t.SearchKey(4);
	t.SearchKey(7);
	t.Remove(5);
	t.Remove(6);
	t.Remove(456);
	t.SearchKey(5);
	t.SearchKey(1);
	t.SearchKey(2);
	t.SearchKey(4);
	t.SearchKey(7);
	
}
