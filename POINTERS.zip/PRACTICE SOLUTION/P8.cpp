#include<iostream>
using namespace std;
const int hash_table_size = 200;
class HashNode
{
	public:
		int key;
		int value;
		HashNode* next;
		HashNode()
		{
			next = NULL;
		}
		HashNode(int key,int value)
		{
			this->key = key;
			this->value = value;
			next = NULL;
		}
};
class HashTable
{
	private:
		HashNode** ht;
	public:	
		HashTable()
		{
			ht = new HashNode*[hash_table_size];
			for(int i = 0 ; i < hash_table_size;i++)
			{
				ht[i] = NULL;
			}
		}
		int hash_function(int key)
		{
			return key%hash_table_size;
		}
		void insert(int key,int value)
		{
			int hash_value = hash_function(key);
			HashNode* ptr = ht[hash_value];
			HashNode* temp = NULL;
			while(ptr != NULL)
			{
				temp = ptr;
				ptr = ptr->next;
			}
			ptr = new HashNode;
			ptr->key = key;
			ptr->value = value;
			if(temp == NULL)
			{
				ht[hash_value] = ptr;
			}
			else
			{
				temp->next = ptr;
			}
		}
		void search(int key)
		{
			int hash_value = hash_function(key);
			bool flag;
			HashNode* ptr = ht[hash_value];
			if (ptr != NULL)
		  	{
            	while (ptr != NULL)
				{
               		if (ptr->key == key) 
			   		{
                		flag = true;
               		}	
               		if(flag)
			    	{
                  		cout<<"ELEMENT OF KEY : "<<key<<endl;
                  		cout<<"VALUE AT THAT KEY : "<<ptr->value<<endl<<endl;
               		}
               		ptr = ptr->next;
           		 }
         	}
         	if(!flag)
         	{
           		cout<<"KEY DOES NOT FOUND "<<key<<endl;
		 	}
		}
		void delete_data(int key)
		{
			int hash_value = hash_function(key);
			HashNode* ptr = ht[hash_value];
			HashNode* temp = NULL;
			if(ptr == NULL || ptr->key != key)
			{
				cout<<"NO DATA FOUND!"<<endl;
				return;
			}
			while(ptr->next != NULL)
			{
				temp = ptr;
				ptr = ptr->next;
			}
			if(temp != NULL)
			{
				temp->next = ptr->next;
			}
			cout<<"DATA HAS BEEN DELETE AT KEY "<<ptr->key<<endl;
			delete ptr;
		}
};
int main()
{
	HashTable t;
	t.insert(1,345);
	t.insert(2,567);
	t.insert(456,2132);
	t.insert(5,23523);
	t.insert(5,78978);
	t.insert(5,9038);
	t.insert(3232,553);
	t.search(5);
	t.search(1);
	t.search(2);
	t.search(4);
	t.search(7);
	cout<<"\n\n";
	t.delete_data(5);
	t.delete_data(456);
	t.delete_data(6);
	t.delete_data(1);
	cout<<"\n\n";
	t.search(5);
	t.insert(5,3875);
	t.search(5);
	t.search(1);
	t.search(2);
	t.search(4);
	t.search(7);
	return 0;
}













