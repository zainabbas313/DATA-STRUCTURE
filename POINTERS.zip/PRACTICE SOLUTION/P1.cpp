#include<iostream>
using namespace std;
class node1
{
	public:
		int data;
		node1* next;
		node1()
		{
			next = NULL;
		}
		node1(int data)
		{
			next = NULL;
			this->data = data;
		}
};
class sll2
{
	public:
		sll2()
		{
				
		}
		sll2(int data,node1* head)
		{
			node1* ptr = new node1;
			ptr->data = data;
			ptr->next = NULL;
			head = NULL;	
		}	
		node1* insert(int data,node1* head)
		{
			node1* ptr = new node1;
			ptr->data = data;
			if(head == NULL)
			{
				ptr->next = NULL;
				head = ptr;
				return head;
			}
			node1* temp = head;
			while(temp->next != NULL)
			{
				temp = temp->next;
			}
			temp->next = ptr;
			ptr->next = NULL;
			return head;
		}
		void display(node1* head)
		{
			node1* temp = head;
			while(temp != NULL)
			{
				cout<<temp->data<<" ";
				temp = temp->next;
			}
			cout<<endl;
		}
};
class node
{
	public:
		string data;
		node* next;
		node()
		{
			next = NULL;
		}
		node(string data)
		{
			next = NULL;
			this->data = data;
		}
};
class sll1
{
	private:
		node* head;
	public:
		sll1()
		{
			head = NULL;	
		}
		sll1(string data)
		{
			node* ptr = new node;
			ptr->data = data;
			ptr->next = NULL;
			head = NULL;	
		}	
		void insert(string data)
		{
			node* ptr = new node;
			ptr->data = data;
			if(head == NULL)
			{
				ptr->next = NULL;
				head = ptr;
				return;
			}
			node* temp = head;
			while(temp->next != NULL)
			{
				temp = temp->next;
			}
			temp->next = ptr;
			ptr->next = NULL;
		}
		void delete_node(node1* temp1)
		{
			int a = 0;
			while(temp1 != NULL)
			{
				node* hold = head;
				node* temp = head;
				if(temp1->data == 1)
				{
					a+=2;
					temp = temp->next;
					head = temp;
					delete hold;
				}
				else
				{
					for( int i = a ; i < temp1->data;i++)
					{
						hold = temp;
						temp = temp->next;
						
						if(temp == NULL)
						{
							cout<<"EMPTY!"<<endl;
							return;
						}
					}
					a++;
					hold->next = temp->next;
					delete temp;
				}
				temp1 = temp1->next;
			}
		}
		void display()
		{
			node* temp = head;
			while(temp != NULL)
			{
				cout<<temp->data<<" ";
				temp = temp->next;
			}
			cout<<endl;
		}
};
int main()
{
	node1* head = NULL;
	sll2 l2;
	head = l2.insert(1,head);
	head = l2.insert(4,head);
	head = l2.insert(10,head);
	head = l2.insert(5,head);
	head = l2.insert(7,head);
	head = l2.insert(15,head);
	l2.display(head);
	sll1 l1;
	l1.insert("A");
	l1.insert("B");
	l1.insert("C");
	l1.insert("D");
	l1.insert("E");
	l1.insert("F");
	l1.insert("G");
	l1.insert("H");
	l1.insert("I");
	l1.insert("J");
	l1.display();
	l1.delete_node(head);
	l1.display();
	return 0;
}

