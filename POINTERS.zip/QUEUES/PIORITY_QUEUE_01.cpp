#include<iostream>
using namespace std;
class node
{
  public:
    int data;
    int priority;
    node* next;
    node* prev;
    node()
    {
        next = prev = NULL;
    }
    node(int data,int priority)
    {
        this->data= data;
        this->priority = priority;
        next = prev = NULL;
    }
};
class priority_queue
{
    private: 
        node* head;
    public:
        priority_queue()
        {
            node* ptr = new node;
            cout<<"ENTER THE DATA : ";
            cin>>ptr->data;
            cout<<"SET THE PRIORITY : ";
            cin>>ptr->priority;
            head = ptr;
            ptr->next = NULL;
            ptr->prev = NULL;
        }
        priority_queue(int x, int p)
        {
            node* ptr = new node;
            ptr->data = x;
            ptr->priority = p;
            head = ptr;
            ptr->next = ptr->prev = NULL;
        }
        void enqueue(int x, int p)
        {
            // cout<<"zain";
            node* ptr = new node;
            ptr->data = x;
            ptr->priority = p;
            if(head == NULL)
            {
                head = ptr;
                ptr->next = ptr->prev = NULL;
                return;
            }
            node* temp2 = NULL;
            node* temp1 = head;
            while(temp1 != NULL)
            {
                if(ptr->priority >= temp1->priority)
                {
                    if(temp1->prev == NULL)
                    {
                        node* hold = temp1;
                        head = ptr;
                        ptr->next = hold;
                        hold->prev = ptr;
                        ptr->prev = NULL;
                        return;
                    }
                    else
                    {
                        node* hold = temp2;
                        temp2->next = ptr;
                        ptr->next =temp1;
                        temp1->prev = ptr;
                        ptr->prev = temp2;
                        return;
                    }
                }
                temp2 = temp1;
                temp1 = temp1->next;
            }
            temp2->next = ptr;
            ptr->next = NULL;
            ptr->prev = temp2;
        }
        int peek()
        {
            node* temp = head;
            head = temp->next;
            int x = temp->data;
            delete temp;
            return x;
        }
        void display()
        {
            node* temp = head;
            cout<<endl;
            while(temp != NULL)
            {
                cout<<temp->data<<" ";
                temp = temp->next;
            }
            cout<<endl;
        }
};
int main()
{
    priority_queue list(1,10);
    list.enqueue(2,20);
    list.enqueue(3,30);
    list.enqueue(4,31);
    list.enqueue(5,25);
    list.enqueue(6,1);
    list.enqueue(7,86);
    list.display();
    cout<<"DEQUEUE THE TOP : "<<list.peek();
    list.display();
    return 0;
}

