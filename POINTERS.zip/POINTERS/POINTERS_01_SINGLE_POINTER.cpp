#include<iostream>
using namespace std;

int main()
{
	int array[5] = {1,2,3,4,5};
	
	//this contain the 1st element address, or 1st index address
	int *ptr_1 = array;
	
	//this contain the address of whole array address, 
	int (*ptr_2)[5] = &array;
	
	//both contain value of first index of array
	cout<<"ARRAY[0] = "<<array[0]<<"    *ptr_1 = "<<*ptr_1<<endl;
	
	//both contain the address of the first address
	cout<<"&ARRAY[0] = "<<&array[0]<<"  ptr_1 = "<<ptr_1<<endl;
	
	//*ptr_2 and ptr_2 both contain the address of first element of array
	cout<<"ARRAY[0] = "<<array[0]<<"    *ptr_2 = "<<*ptr_2<<endl;
	
	//same, having the address of 1st element of address
	cout<<"ARRAY = "<<array<<"  ptr_2 = "<<ptr_2<<endl;
	
	//**ptr_2 contain the value of 1st index value, because array is also a pointer, so 
	// we can say that ptr_2 may call as a pointer to pointer
	//0 index
	cout<<"ARRAY[0] = "<<array[0]<<"  **ptr_2 = "<<(**ptr_2)<<" address of [0] = "<<&array[0]<<endl;
	
	//1 index
	cout<<"ARRAY[1] = "<<array[1]<<"  **ptr_2 = "<<++(**ptr_2)<<" address of [1] = "<<&array[1]<<endl;
	
	//2 index
	cout<<"ARRAY[2] = "<<array[2]<<"  **ptr_2 = "<<++(**ptr_2)<<" address of [2] = "<<&array[2]<<endl;
	
	//3 index
	cout<<"ARRAY[3] = "<<array[3]<<"  **ptr_2 = "<<++(**ptr_2)<<" address of [3] = "<<&array[3]<<endl;
	
	//4 index
	cout<<"ARRAY[4] = "<<array[4]<<"  **ptr_2 = "<<++(**ptr_2)<<" address of [4] = "<<&array[4]<<endl;
	
	//each index of array contain different address with difference of 4 bits
	cout<<"&ARRAY[0] = "<<&array[0]<<"  &ARRAY[1] = "<<&array[1]<<" &ARRAY[2] = "<<&array[2]<<endl;
	
	return 0;
}

