#include<iostream>
using namespace std;
int main()
{
	//incomplete, print addresses
	int **p;
	p = new int*[2];
	for(int  i = 0; i < 2 ; i++)
	{
		p[i] = new int[3];
	}
	for(int i = 0; i<2;i++)
	{
		for(int j=0;j <3;j++)
		{
			//also write as: 
//			cin>>*(*(p+i)+j);
			cin>>p[i][j];
		}
	}
	
	cout<<"p = "<<p<<"	*p = "<<*p<<"	&p[0] = "<<&p[0]<<"	(p+0) = "<<(p+0)<<"	*(p+0) = "<<*(p+0)<<endl;
	cout<<"*p[0] = "<<*p[0]<<"	*(p+0) = "<<**(p+0)<<"	p[0] = "<<p[0]<<"	(p+0) = "<<(p+0)<<endl;
	
}
