#include<iostream>
using namespace std;

int main()
{
	int array[5] = {5,6,1.4,2};
	int** ptr;
	ptr = new int*[5];
	
	for(int i = 0; i < 5; i++ )
	{
		ptr[i] = new int;
	}
	for(int i=0; i<5 ;i++)
	{
		for(int j = 0;j<5 ; j++)
		{
			
		}
	}
	for(int i = 0; i < 5; i++ )
	{
		cout<<ptr[i] <<" "<<&array[i]<<endl;
	}
	return 0;
}

