#include<iostream>
using namespace std;
int main()
{
    int a[2][2];
    int (*ptr_1)[2] = a;
    
    for(int  i = 0; i < 2;i++)
    {
        for(int j = 0;j < 2;j++)
        {
            cin>>a[i][j];
        }
    }
    
    for(int  i = 0; i < 2;i++)
    {
        for(int j = 0;j < 2;j++)
        {
            cout<<"a["<<i<<"]["<<j<<"] = "<<a[i][j]<<"  *ptr_1 = "<<(**ptr_1)<<"    &a[i][j] = "<<&a[i][j]<<endl;
            ++(**ptr_1);

        }
    }
    
    int a1[2][2];
    int (*ptr_2)[2][2] = &a1;
    for(int  i = 0; i < 2;i++)
    {
        for(int j = 0;j < 2;j++)
        {
            cin>>a1[i][j];
        }
    }
    
    for(int  i = 0; i < 2;i++)
    {
        for(int j = 0;j < 2;j++)
        {
            cout<<"a1["<<i<<"]["<<j<<"] = "<<a1[i][j]<<"  ***ptr_2 = "<<(***ptr_2)<<"    &a[i][j] = "<<&a1[i][j]<<endl;
            ++(***ptr_2);

        }
    }
    
}
