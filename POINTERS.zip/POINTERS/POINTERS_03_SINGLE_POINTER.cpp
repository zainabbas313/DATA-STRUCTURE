#include<iostream>
using namespace std;
int main()
{
	int a[5] = {1,2,3,4,5};
	int *p = a;
	cout<<"a = "<<a<<"	&a[0] = "<<&a[0]<<"	&a = "<<&a<<"	(a+0) = "<<(a+0)<<endl;
	cout<<"a[0] = "<<a[0]<<"	0[a] = "<<0[a]<<"	*(a+0) = "<<*(a+0)<<endl;
	
	cout<<"p = "<<p<<"	&p[0] = "<<&p[0]<<"	&p = "<<&p<<"	(p+0) = "<<(p+0)<<"	*p = "<<*p<<endl;
	cout<<"p[0] = "<<p[0]<<"	0[p] = "<<0[p]<<"	*(p+0) = "<<*(p+0)<<endl;
}
