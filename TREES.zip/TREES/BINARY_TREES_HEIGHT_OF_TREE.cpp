#include<iostream>
using namespace std;
class node
{
	public:
	 	int data;
	 	node *left;
	 	node *right;
		node()
		{
			left = right = NULL;
		}	
		node(int data)
		{
			node *ptr = new node;
			this->data = data;
			ptr->right = ptr->left = NULL;
		}
};
class binary_tree
{
	private:
		node * root;
	public:
		binary_tree()
		{
			root = NULL;	
		}	
		binary_tree(int x)
		{
			node * ptr = new node;
			ptr->data = x;
			root = ptr;
		}
		void insert(int x)
		{
			node * ptr = new node;
			if(root == NULL)
			{
				ptr->data = x;
				root = ptr;
				return;
			}
			node* temp = root;
			inserting(temp,ptr,x);
		}
		node* inserting(node* root,node* ptr,int x)
		{
			if(root == NULL)
			{
				ptr->data = x;
				root = ptr;
				return root;
			}
			else if(root->data > x)
			{
				root->left = inserting(root->left,ptr,x);
			}
			else
			{
				root->right = inserting(root->right,ptr,x);
			}
			return root;
		}
		void print()
		{
			node *temp = root;
			pre_order(temp);
			cout<<endl;
			post_order(temp);
			cout<<endl;
			in_order(temp);	
		}
		void pre_order(node *root)
		{
			if(root != NULL)
			{
				cout<<root->data<<" ";
				pre_order(root->left);
				pre_order(root->right);
			}
		}
		void in_order(node *root)
		{
			if(root != NULL)
			{
				in_order(root->left);
				cout<<root->data<<" ";
				in_order(root->right);
			}
		}
		void post_order(node *root)
		{
			if(root != NULL)
			{
				post_order(root->left);
				post_order(root->right);
				cout<<root->data<<" ";
			}
		}
		void insert_without_recurives(int x)
		{
			node* ptr = new node;
			node* temp = root;
			node* hold = NULL;
			ptr->data = x;
			if(root == NULL)
			{
				root = ptr;
				return;
			}
			while(true)
			{
				hold = temp;
				if(temp->data > x)
				{
					temp = temp->left;
					if(temp == NULL)
					{
						hold->left = ptr;
						return;
					}
				}
				else
				{
					temp = temp->right;
					if(temp == NULL)
					{
						hold->right = ptr;
						return;
					}
				}
			}
		}
		void search(int x)
		{
			node* temp = root;
			if(root == NULL)
			{
				cout<<"EMPTY TREE"<<endl;
				return;
			}
			while(temp->data != x)
			{
				if(temp != NULL)
				{
					cout<<temp->data<<" ";
					if(temp->data > x)
					{
						temp = temp->left;
					}
					else
					{
						temp = temp->right;
					}
					if(temp == NULL)
					{
						return;
					}
				}
			}
			
		}
		void delete_node(int x)
		{
			node* temp = root;
			deletetree(temp,x);
		}
		node* deletetree(node* temp,int x) 
		{ 
			if(temp == NULL)
			{
				cout<<"NO SUCH NODE IS FOUND!"<<endl;
				return NULL;
			}
			else if(temp->data > x)
			{
				temp->left = deletetree(temp->left,x);
			}
			else if(temp->data < x)
			{
				temp->right = deletetree(temp->right,x);
			}
			else
			{
				if(temp->left == NULL && temp->right == NULL)
				{
					delete temp;
					return NULL;
				}
				else if(temp->left == NULL)
				{
					node* hold = temp;
					temp= temp->right;
					delete hold;
				}
				else if(temp->right == NULL)
				{
					node* hold = temp;
					temp= temp->left;
					delete hold;
				}
				else
				{
					node* hold = findmin(temp->right);
					temp->data = hold->data;
					temp->right = deletetree(temp->right,hold->data);
				}
			}
			return temp;
		}	
		node* findmin(node* temp)
		{
			while(temp->left != NULL) 
			{
        		temp = temp->left;
    		}
    		return	temp;
		}
		void height()
		{
		    node* temp = root;
		    int x = tree_height(temp);
		    delete temp;
		    cout<<"HEIGHT IS  : "<<x<<endl;;
		}
		int tree_height(node* root)
		{
            if (!root)
            {
                return 0;
            }
            else
            {
                int left_height = tree_height(root->left);
                int right_height = tree_height(root->right);
                if(left_height >= right_height)
                {
                    return left_height + 1;
                }
                else
                {
                    return right_height + 1;
                }
            }
    }
};
int main()
{
	binary_tree list(20);
	binary_tree list1;
	list.insert_without_recurives(8);
	list.insert_without_recurives(6);
	list.insert_without_recurives(10);
	list.insert_without_recurives(7);
	list.insert_without_recurives(11);
	list.delete_node(8);
	list.print();
	cout<<endl<<endl;
	list1.insert(80);
	list1.insert(60);
	list1.insert(70);
	list1.insert(30);
	list1.insert(20);
	list1.insert(35);
	list1.insert(75);
	list1.insert(65);
	list1.insert(74);
	list1.insert(72);
	list1.insert(73);
	list1.insert(25);
	list1.print();
	cout<<endl;
	list1.height();
	return 0;
}

