#include<iostream>
using namespace std;
class node
{
	public:
	 	int data;
	 	node *left;
	 	node *right;
		node()
		{
			left = right = NULL;
		}	
		node(int data)
		{
			node *ptr = new node;
			this->data = data;
			ptr->right = ptr->left = NULL;
		}
};
class binary_tree
{
	private:
		node * root;
	public:
		binary_tree()
		{
			root = NULL;	
		}	
		binary_tree(int x)
		{
			node * ptr = new node;
			ptr->data = x;
			root = ptr;
		}
		void insert(int x)
		{
			node * ptr = new node;
			if(root == NULL)
			{
				ptr->data = x;
				root = ptr;
				return;
			}
			node* temp = root;
			inserting(temp,ptr,x);
		}
		node* inserting(node* root,node* ptr,int x)
		{
			if(root == NULL)
			{
				ptr->data = x;
				root = ptr;
				return root;
			}
			else if(root->data > x)
			{
				root->left = inserting(root->left,ptr,x);
			}
			else
			{
				root->right = inserting(root->right,ptr,x);
			}
			return root;
		}
		void print()
		{
			node *temp = root;
			pre_order(temp);
			cout<<endl;
			post_order(temp);
			cout<<endl;
			in_order(temp);	
		}
		void pre_order(node *root)
		{
			if(root != NULL)
			{
				cout<<root->data<<" ";
				pre_order(root->left);
				pre_order(root->right);
			}
		}
		void in_order(node *root)
		{
			if(root != NULL)
			{
				in_order(root->left);
				cout<<root->data<<" ";
				in_order(root->right);
			}
		}
		void post_order(node *root)
		{
			if(root != NULL)
			{
				post_order(root->left);
				post_order(root->right);
				cout<<root->data<<" ";
			}
		}
		void insert_without_recurives(int x)
		{
			node* ptr = new node;
			node* temp = root;
			node* hold = NULL;
			ptr->data = x;
			if(root == NULL)
			{
				root = ptr;
				return;
			}
			while(1)
			{
				hold = temp;
				if(temp->data > x)
				{
					temp = temp->left;
					if(temp == NULL)
					{
						hold->left = ptr;
						return;
					}
				}
				else
				{
					temp = temp->right;
					if(temp == NULL)
					{
						hold->right = ptr;
						return;
					}
				}
			}
		}
		void search(int x)
		{
			node* temp = root;
			if(root == NULL)
			{
				cout<<"EMPTY TREE"<<endl;
				return;
			}
			while(temp->data != x)
			{
				if(temp != NULL)
				{
					cout<<temp->data<<" ";
					if(temp->data > x)
					{
						temp = temp->left;
					}
					else
					{
						temp = temp->right;
					}
					if(temp == NULL)
					{
						return;
					}
				}
			}
			
		}
		void delete_node(int x)
		{
			node* temp = root;
			deletetree(temp,x);
		}
		node* deletetree(node* temp,int x) 
		{ 
			if(temp == NULL)
			{
				cout<<"NO SUCH NODE IS FOUND!"<<endl;
				return NULL;
			}
			else if(temp->data > x)
			{
				temp->left = deletetree(temp->left,x);
			}
			else if(temp->data < x)
			{
				temp->right = deletetree(temp->right,x);
			}
			else
			{
				if(temp->left == NULL && temp->right == NULL)
				{
					delete temp;
					return NULL;
				}
				else if(temp->left == NULL)
				{
					node* hold = temp;
					temp= temp->right;
					delete hold;
				}
				else if(temp->right == NULL)
				{
					node* hold = temp;
					temp= temp->left;
					delete hold;
				}
				else
				{
					node* hold = findmin(temp->right);
					temp->data = hold->data;
					temp->right = deletetree(temp->right,hold->data);
				}
			}
			return temp;
		}	
		node* findmin(node* temp)
		{
    		node* temp = temp;
			while(temp->left != NULL) 
			{
        		temp = temp->left;
    		}
    		return	temp;
		}
};
int main()
{
	binary_tree list(1);
	binary_tree list1;
	list.insert_without_recurives(2);
	list.insert_without_recurives(3);
	list.insert_without_recurives(4);
	list.insert_without_recurives(5);
	list.delete_node(5);
 	list.print();
// 	cout<<endl<<endl;;
	list1.insert(8);
	list1.insert(6);
	list1.insert(9);
	list1.insert(5);
	list1.insert(7);
	list1.insert(4);
	list1.insert(10);
// 	list1.delete_node(3);
	list1.print();
	return 0;
}

