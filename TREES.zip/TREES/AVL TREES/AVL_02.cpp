#include<iostream>
using namespace std;
class graph_mutual_friend_node
{
	public:
		int number_of_mutuals;
		string friend_name;
		string friend_to_friend;
		string names_of_mutuals[3];
		graph_mutual_friend_node *left;
		graph_mutual_friend_node *right;
		graph_mutual_friend_node()
		{
			left = right = NULL;
			this->number_of_mutuals = 0 ;
			for(int i = 0; i < 3;i++)
			{
				names_of_mutuals[i] = '\0';
			}
		}
		graph_mutual_friend_node(string friend_name)
		{
			this->friend_name = friend_name;
		}
};
class AVL_FOR_MUTAUL_FRIENDS
{
	private:
		graph_mutual_friend_node * root;
	public:
		AVL_FOR_MUTAUL_FRIENDS()
		{
			root = NULL;	
		}	
		AVL_FOR_MUTAUL_FRIENDS(string f_name,string ff_name)
		{
			graph_mutual_friend_node* ptr = new graph_mutual_friend_node;
			ptr->friend_name = f_name;
			ptr->friend_to_friend = ff_name;
			ptr->names_of_mutuals[ptr->number_of_mutuals] = f_name;
			ptr->number_of_mutuals = ptr->number_of_mutuals + 1;
			root = ptr;
		}
		void insert(string f_name,string ff_name)
		{
			int i = 0;
			if(root == NULL)
			{
				graph_mutual_friend_node* ptr = new graph_mutual_friend_node;
				ptr->friend_name = f_name;
				ptr->friend_to_friend = ff_name;
				ptr->names_of_mutuals[ptr->number_of_mutuals] = f_name;
				ptr->number_of_mutuals = ptr->number_of_mutuals + 1;
				root = ptr;
				return;
			}
			graph_mutual_friend_node* temp = root;
			root = inserting(temp,f_name,ff_name,0);
		}
		graph_mutual_friend_node* inserting(graph_mutual_friend_node* root,string f_name,string ff_name,int itrator)
		{
			if(root == NULL)
			{
				graph_mutual_friend_node* ptr = new graph_mutual_friend_node;
				ptr->friend_to_friend = ff_name;
				ptr->friend_name = f_name;
				ptr->names_of_mutuals[ptr->number_of_mutuals] = f_name;
				ptr->number_of_mutuals = ptr->number_of_mutuals + 1;
				root = ptr;
				return root;
			}
			if(root->friend_to_friend == ff_name)
			{
				root->names_of_mutuals[root->number_of_mutuals] = f_name;
				root->number_of_mutuals = root->number_of_mutuals + 1;
				return root;
			}
			else if(root->friend_to_friend[itrator] == ff_name[itrator])
			{
				while(root->friend_name[itrator] != ff_name[itrator])
				{
					itrator++;
				}
			}
			if(root->friend_to_friend[itrator] > ff_name[itrator])
			{
				root->left = inserting(root->left,f_name,ff_name,itrator);
			}
			else if(root->friend_to_friend[itrator] < ff_name[itrator])
			{
				root->right = inserting(root->right,f_name,ff_name,itrator);
			}
			else
			{
				int bf = balanced_factor(root);
				if(bf > 1 && root->left->friend_to_friend[itrator] > ff_name[itrator])
				{
				    return rotate_right(root);
				}
				else if(bf < -1 && root->right->friend_to_friend[itrator] < ff_name[itrator])
				{
				    return rotate_left(root);
				}
				else if(bf > 1 && root->left->friend_to_friend[itrator] < ff_name[itrator])
				{
				    root->left = rotate_left(root);
				    return rotate_right(root);
				}
				else if(bf < -1 && root->right->friend_to_friend[itrator] > ff_name[itrator])
				{
				    root->right = rotate_right(root);
				    return rotate_left(root);
				} 
			} 
			return root;
		}
		graph_mutual_friend_node* rotate_right(graph_mutual_friend_node* root)
		{
		    graph_mutual_friend_node* temp = root->left;
		    graph_mutual_friend_node* hold = temp->right;
		    temp->right = root;
		    root->left = hold;
		    return temp;
		}
		graph_mutual_friend_node* rotate_left(graph_mutual_friend_node* root)
		{
		    graph_mutual_friend_node* temp = root->right;
		    graph_mutual_friend_node* hold = temp->left;
		    temp->left = root;
		    root->right = hold;
		    return temp;
		}
		void print()
		{
			graph_mutual_friend_node *temp = root;
			post_order(temp);	
			cout<<endl<<"HEIGHT : "<<height(root);
		}
		void post_order(graph_mutual_friend_node *root)
		{
			if(root != NULL)
			{
				if(root->number_of_mutuals != 1)
				{
					cout<<"\t\t"<<root->friend_to_friend<<" is mutual of : ";
					for(int i = 0; i < root->number_of_mutuals ; i++)
					{
						cout<<"  "<<root->names_of_mutuals[i];
					}
					cout<<endl;
				}
				post_order(root->left);
				post_order(root->right);
				//cout<<root->friend_to_friend<<" ";
			}
		}
		
		graph_mutual_friend_node* findmin(graph_mutual_friend_node* temp)
		{
			while(temp->left != NULL) 
			{
        		temp = temp->left;
    		}
    		return	temp;
		}
		int balanced_factor(graph_mutual_friend_node* root)
		{
		    if(root == NULL)
		    {
		        return -1;
		    }
		    return (height(root->left) - height(root->right));
		}
		int height(graph_mutual_friend_node* root)
		{
		    if(root == NULL)
		    {
		        return -1;
		    }
		    else
		    {
		        int lh = height(root->left);
		        int rh = height(root->right);
		        if(lh > rh)
		        {
		            return (lh + 1);
		        }
		        else
		        {
		            return (rh + 1);
		        }
		    }
		}
};
int main()
{
	AVL_FOR_MUTAUL_FRIENDS list1;
	list1.insert("x","haseeb");
	list1.insert("y","zain");
	list1.insert("x","hannan");
	list1.insert("m","salman");
	list1.insert("c","kasim");
	list1.insert("d","hasan");
	list1.insert("s","zain");
	list1.insert("g","salman");
	list1.insert("d","kasim");
	list1.insert("f","hasan");
	cout<<endl<<endl;;
	list1.print();
	return 0;
}

