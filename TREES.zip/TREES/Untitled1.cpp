#include<iostream>
using namespace std;
class node
{
	public:
		int data;
		node* next;
		node()
		{
			next = NULL;	
		}
		node(int data, next = NULL)
		{
			this->data = data;
		}
};
class BST
{
	private:
	 	node* root;
	public:
		BST()
		{
			root = Null;
		}
		BST(int val)
		{
			node* ptr = new node;
			ptr->data = val;
			root = ptr;
		}
		void insert(int val)
		{
			node* ptr = new node;
			ptr->data = val;
			if(root == NULL)
			{
				root = ptr;
				return;
			}
			nodE* temp = root;
			insertion(temp,ptr);
			delete temp;
		}		
		node* insertion(node* temp, node* ptr)
		{
			if(temp == NULL)
			{
				temp = ptr;
				return temp;
			}
			if(temp->data > ptr->data)
			{
				temp->left = insertion(temp->left,ptr);
			}
			else
			{
				temp->right = insertion(temp->right,ptr);
			}
			return temp;
		}
		void display()
		{
			node* temp = root;
			in_order(temp);
			node* in_order(node* temp)
			{
				if(temp == NULL)
				{
					return temp;
				}
				in_order(temp->left);
				cout<<temp->data<<" ";
				in_order(temp->right);
			}
		}
};
int main()
{

	return 0;
}

