#include<iostream>
using namespace std;
template <class t>
class node
{
    public:
        t data;
        node<t>* left;
        node<t>* right;
    node()
    {
        left = right = NULL;
    }
    node(t data)
    {
        this->data = data;
        left = right = NULL;
    }
};
template<class t>
class bst
{
    private:
        node<t>* root;
    public:
        bst()
        {
            root = NULL;            
        }
        bst(t x)
        {
            node<t>* ptr = new node<t>;
            ptr->data = x;
            ptr->left = ptr->right = NULL;
            root = ptr;
        }
        void insert(t x)
        {
            node<t>* ptr = new node<t>;
            if(root == NULL)
            {
                ptr->data = x;
                root = ptr;
                return;
            }
            node<t>* temp = root;
            insertion(temp,ptr,x);
        }
        node<t>* insertion(node<t>* temp,node<t>* ptr,t x)
        {
            if(temp == NULL)
            {
                ptr->data = x;
                temp = ptr;
                return temp;
            }
            else
            {
                if(temp->data > x)
                {
                    temp->left = insertion(temp->left,ptr,x);
                }
                else
                {
                    temp->right = insertion(temp->right,ptr,x);   
                }
            }
            return temp;
        }
        void display()
        {
            node<t>* temp = root;
            post_order(temp);
        }
        void post_order(node<t>* temp)
        {
            if(temp != NULL)
            {
                post_order(temp->left);
                cout<<temp->data<<" ";
                post_order(temp->right);
            }
        }
        void delete_node(t x)
        {
            if(root == NULL)
            {
                cout<<"EMPTY"<<endl;
                return;
            }
            node<t>* temp = root;
            deletion(temp,x);
        }
        node<t>* deletion(node<t>* temp,t x)
        {
            if(temp == NULL)
            {
                return temp;
            }
            else if(temp->data > x)
            {
                temp->left = deletion(temp->left,x);
            }
            else if(temp->data < x)
            {
                temp->right = deletion(temp->right,x);
            }
            else
            {
                if(temp->left == NULL && temp->right == NULL)
                {
                    delete temp;
                }
                else if(temp->left == NULL)
                {
                    node<t>* hold = temp;
                    temp = temp->right;
                    delete hold;
                }
                else if(temp->right == NULL)
                {
                    node<t>* hold = temp;
                    temp = temp->left;
                    delete hold;
                }
                else
                {
                    node<t>* hold = findmin(temp->right);
                    temp->data = hold->data;
                    temp->right = deletion(temp->right,hold->data);
                }
            }
            return temp;
        }
        node<t>* findmin(node<t>* temp)
        {
            while(temp != NULL)
            {
                temp = temp->left;
            }
            return temp;
        }
        node<t>* findmax(node<t>* temp)
        {
            while(temp != NULL)
            {
                temp = temp->right;
            }
            return temp;
        }
        void count_same_node(t var)
        {
        	node<t>* temp = root;
        	counting(temp,var);
		}
		void counting(node<t>* temp,t var)
		{
			static int flag = 0;
        	if(temp != NULL)
        	{
				if(temp->data > var)
				{
				    counting(temp->left,var);
				}
				else if(temp->data < var)
				{
				    counting(temp->right,var);
				}
				else
				{
				    flag++;
				    counting(temp->right,var);
				}
			} 
			if(temp == root)
			{
				cout<<"NUMBER OF "<<var<<" IS : "<<flag<<endl;
			}
		}
		void least_common_node(t var1,t var2)
		{
		    node<t>* temp = root;
		    temp = lcn(temp,var1,var2);
		    cout<<"LEAST COMMON NODE IS : "<<temp->data<<endl;
		}
		node<t>* lcn(node<t>* temp,t var1, t var2)
		{
		    static node<t>* hold = NULL;
		    if(temp->data > var1 && temp->data < var2)
		    {
		        hold = temp;
		    }
		    else
		    {
		        if(temp->data > var1 && temp->data > var2)
		        {
		            temp->left = lcn(temp->left,var1,var2);
		        }
		        else
		        {
		            temp->right = lcn(temp->right,var1,var2);   
		        }
		    }
		    return hold;
		}
};

int main()
{
    bst<int> list(80);
    list.insert(50);
    list.insert(90);
    list.insert(30);
    list.insert(55);
    list.insert(82);
    list.insert(95);
    list.insert(7);
    list.insert(8);
    list.insert(51);
    list.insert(56);
    list.insert(81);
    list.insert(85);
    list.insert(92);
    list.insert(98);
    list.display();
    cout<<endl;
    list.count_same_node(5);
    list.least_common_node(7,56);
    return 0;
}




