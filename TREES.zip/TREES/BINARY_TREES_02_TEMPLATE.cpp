#include<iostream>
using namespace std;
template <class t>
class node
{
    public:
        t data;
        node<t>* left;
        node<t>* right;
    node()
    {
        left = right = NULL;
    }
    node(t data)
    {
        this->data = data;
        left = right = NULL;
    }
};
template<class t>
class bst
{
    private:
        node<t>* root;
    public:
        bst()
        {
            root = NULL;            
        }
        bst(t x)
        {
            node<t>* ptr = new node<t>;
            ptr->data = x;
            ptr->left = ptr->right = NULL;
            root = ptr;
        }
        void insert(t x)
        {
            node<t>* ptr = new node<t>;
            if(root == NULL)
            {
                ptr->data = x;
                root = ptr;
                return;
            }
            node<t>* temp = root;
            insertion(temp,ptr,x);
        }
        node<t>* insertion(node<t>* temp,node<t>* ptr,t x)
        {
            if(temp == NULL)
            {
                ptr->data = x;
                temp = ptr;
                return temp;
            }
            else
            {
                if(temp->data > x)
                {
                    temp->left = insertion(temp->left,ptr,x);
                }
                else
                {
                    temp->right = insertion(temp->right,ptr,x);   
                }
            }
            return temp;
        }
        void display()
        {
            node<t>* temp = root;
            post_order(temp);
        }
        void post_order(node<t>* temp)
        {
            if(temp != NULL)
            {
                post_order(temp->left);
                cout<<temp->data<<" ";
                post_order(temp->right);
            }
        }
        void delete_node(t x)
        {
            if(root == NULL)
            {
                cout<<"EMPTY"<<endl;
                return;
            }
            node<t>* temp = root;
            deletion(temp,x);
        }
        node<t>* deletion(node<t>* temp,t x)
        {
            if(temp == NULL)
            {
                return temp;
            }
            else if(temp->data > x)
            {
                temp->left = deletion(temp->left,x);
            }
            else if(temp->data < x)
            {
                temp->right = deletion(temp->right,x);
            }
            else
            {
                if(temp->left == NULL && temp->right == NULL)
                {
                    delete temp;
                }
                else if(temp->left == NULL)
                {
                    node<t>* hold = temp;
                    temp = temp->right;
                    delete hold;
                }
                else if(temp->right == NULL)
                {
                    node<t>* hold = temp;
                    temp = temp->left;
                    delete hold;
                }
                else
                {
                    node<t>* hold = findmin(temp->right);
                    temp->data = hold->data;
                    temp->right = deletion(temp->right,hold->data);
                    
                }
            }
            return temp;
        }
        node<t>* findmin(node<t>* temp)
        {
            while(temp != NULL)
            {
                temp = temp->left;
            }
            return temp;
        }
        node<t>* findmax(node<t>* temp)
        {
            while(temp != NULL)
            {
                temp = temp->right;
            }
            return temp;
        }
};

int main()
{
    bst<int> list(6);
    list.insert(5);
    list.insert(7);
    list.insert(9);
    list.insert(8);
    list.insert(13);
    list.insert(34);
    list.insert(24);
    list.insert(19);
//    list.delete_node(8);
//    list.delete_node(5);
//    list.delete_node(4);
    list.display();
    return 0;
}




