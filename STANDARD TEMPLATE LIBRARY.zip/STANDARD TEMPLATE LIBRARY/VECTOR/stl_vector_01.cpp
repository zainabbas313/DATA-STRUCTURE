#include<iostream>
#include<vector>
using namespace std;

int main()
{
	//vector is a dynamic array
	vector<int> vec {1,2,3,4,5};
		cout<<"DATA OF VECTOR ARRAY IS : \t";
		for(int i = 0;i < vec.size(); i++)
		{
			cout<<vec[i]<<" ";
		}
		cout<<endl;
		//push_back = insert at end of vector
		vec.push_back(6);
		cout<<"DATA OF VECTOR ARRAY IS : \t";
		for(int i = 0;i < vec.size(); i++)
		{
			cout<<vec[i]<<" ";
		}
		cout<<endl;
		//pop_back = pop up the last element from the array
		vec.pop_back();
		cout<<"DATA OF VECTOR ARRAY IS : \t";
		for(int i = 0;i < vec.size(); i++)
		{
			cout<<vec[i]<<" ";
		}
		cout<<endl;
		//capacity() = capacity of vector to store the data
 		cout<<"DATA OF VECTOR ARRAY IS : \t\n";
		for(int i = 0;i < 10; i++)
		{
			vec.push_back(i);
			cout<<"\t"<<vec.size()<<"   "<<vec.capacity()<<endl;;
		}
		cout<<endl;
		cout<<"DATA OF VECTOR ARRAY IS : \t";
		for(int i = 0;i < vec.size(); i++)
		{
			cout<<vec[i]<<" ";
		}
	return 0;
}

