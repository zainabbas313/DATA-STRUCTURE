#include<iostream>
#include<vector>
using namespace std;
int main()
{
	vector< vector<int> >vec;
	vec.resize(3);
	for(int i = 0 ; i < 3 ;i++)
	{
		for(int j = 0 ; j < 3; j++)
		{
			vec[i].push_back(j);
		}
	}
	for(int i = 0 ; i < vec.size() ;i++)
	{
		for(int j = 0 ; j < vec[i].size(); j++)
		{
			cout<<vec[i][j]<<" ";
		}
		cout<<endl;
	}
	cout<<vec.capacity()<<endl;
	vec.resize(7);
	for(int i = 0 ; i < 7 ;i++)
	{
		for(int j = 0 ; j < 3; j++)
		{
			vec[i].push_back(j);
		}
	}
	for(int i = 0 ; i < vec.size() ;i++)
	{
		for(int j = 0 ; j < vec[i].size(); j++)
		{
			cout<<vec[i][j]<<" ";
		}
		cout<<endl;
	}
	cout<<vec.capacity()<<endl;
	
	return 0;
}

