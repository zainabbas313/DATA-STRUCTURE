#include<iostream>
#include<array>
using namespace std;

void fun(array<int,5> &arr)
{
	//.at() iterator, and if iterator move beyond the array lenght, it will give expection
		cout<<"THE DATA OF AN ARRAY : (using .at())\t";
		for(int i = 0 ; i < arr.size()+1; i++)
		{
			cout<<arr.at(i)<<"\t";
		}
		cout<<endl;
}

int main()
{
	//multiple way to declare or initinalize the array::std
	array<int,5> arr;
	arr = {1,2,3,4,5};
	cout<<"ENTER THE DATA INTO THE ARRAY : ";
	//size() = size of array
		for(int i = 0 ; i < arr.size(); i++)
		{
//			cin>>arr.at(i);
		}
		cout<<"THE DATA OF AN ARRAY : (using .at())\t";
		for(int i = 0 ; i < arr.size(); i++)
		{
			cout<<arr.at(i)<<"\t";
		}
		cout<<endl;
		cout<<"THE DATA OF AN ARRAY : (using [])\t";
		for(int i = 0 ; i < arr.size(); i++)
		{
			cout<<arr[i]<<"\t";
		}
		cout<<endl;
		//.front() == 1st index data of an array
		cout<<"THE DATA OF ARRAY[0] : "<<arr.front()<<endl;
		cout<<"THE DATA OF ARRAY[last index] : "<<arr.back()<<endl;
		cout<<"THE ADDRESS OF ARRAY POINTER (.data())\t : "<<arr.data()<<endl;
		fun(arr);
	return 0;
}

