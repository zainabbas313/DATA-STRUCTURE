#include<iostream>
using namespace std;
template <class t>
class node_queue
{
    public:
        t data;
        node_queue<t>* next;
        node_queue()
        {
            next = NULL;
        }
        node_queue(t data)
        {
            this->data = data;
            next = NULL;
        }
};
template<class t>
class queue
{
    private:
        node_queue<t>* head;
    public:
        queue()
        {
            head = NULL;
        }
        queue(t x)
        {
            node_queue<t>* ptr = new node_queue<t>;
            ptr->data = x;
            head = ptr;
            ptr->next = NULL;
        }
        void push(t x)
        {
            node_queue<t>* ptr = new node_queue<t>;
            ptr->data = x;
            if(head == NULL)
            {
                head = ptr;
                ptr->next = NULL;
                return;
            }
            node_queue<t>* temp = head;
            while(temp->next != NULL)
            {
            	temp = temp->next;
			}
			temp->next = ptr;
			ptr->next = NULL;
        }
        t pop()
        {
			node_queue<t>* temp = head;
        	t x = temp->data;
        	head = head->next;
        	delete temp;
        	return x;
		}
		bool is_empty()
		{
        	if(head == NULL)
        	{
        		return true;
			}
			return false;
		}
};
int main()
{
	queue<int> list;
//	list.push(5);
//		cout<<list.pop()<<" ";
	for(int i = 1 ; i < 8; i++)
	{
		list.push(i);
	}
	for(int i = 1 ; i < 9; i++)
	{
		if(!list.is_empty())
		{
			cout<<list.pop()<<" ";	
		}
		else
		{
			cout<<"QUEUE IS EMPTY"<<endl;
		}
	}
	return 0;
}

