#include<iostream>
using namespace std;
int sum(int x)
{
	if(x == 0)
	{
		return 0;
	}
	int next_sum = sum(x - 1);
	return x + next_sum;
}
int main()
{
	int num;
	cout<<"ENTER A NUMBER OF WHICH YOU THE SUM : ";
	cin>>num;
	cout<<"THE SUM IS : "<<sum(num)<<endl;

	return 0;
}

