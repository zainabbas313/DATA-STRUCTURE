#include<iostream>
using namespace std;
double multiply(double a,int b)
{
	if(b == -1)
	{
		return 1/a;
	}
	return 1/a * multiply(a,b+1);
}
int main()
{
	int x;
	double y;
	cout<<"ENTER TWO POSITIVE NUMBERS : ";
	cin>>x>>y;
	double ans = multiply(x,y);
	cout<<"ANSWER IS : "<<ans<<endl;

	return 0;
}
#include<iostream>
using namespace std;
double multiply(double a,int b)
{
	if(b == -1)
	{
		return 1/a;
	}
	return 1/a * multiply(a,b+1);
}
int main()
{
	int x;
	double y;
	cout<<"ENTER TWO POSITIVE NUMBERS : ";
	cin>>x>>y;
	double ans = multiply(x,y);
	cout<<"ANSWER IS : "<<ans<<endl;

	return 0;
}

