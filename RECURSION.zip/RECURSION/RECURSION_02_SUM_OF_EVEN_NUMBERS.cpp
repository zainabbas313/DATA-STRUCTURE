#include<iostream>
using namespace std;
int sum_of_even(int x)
{
	int sum = 0;
	if(x == 0)
	{
		return 0;
	}
	sum = sum_of_even(x - 2);
	return x + sum;
}
int main()
{
	int num;
	cout<<"ENTER THE NUMBER FROM WHICH THE SUM WILL BE CALCULATED : ";
	cin>>num;
	if(num % 2 == 0)
		cout<<"THE SUM IS : "<<sum_of_even(num)<<endl;
	else
		cout<<"THE SUM IS : "<<sum_of_even(num-1)<<endl;

	return 0;
}

