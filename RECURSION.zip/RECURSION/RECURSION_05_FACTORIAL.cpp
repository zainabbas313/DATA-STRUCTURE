#include<iostream>
using namespace std;
int factorial(int x)
{
	if(x == 1)
	{
		return 1;
	}
	int num = factorial(x-1);
	return x * num;
}
int main()
{
	int num;
	cout<<"ENTER NUMBER : ";
	cin>>num;
	cout<<"ANSWER IS : "<<factorial(num)<<endl;

	return 0;
}

