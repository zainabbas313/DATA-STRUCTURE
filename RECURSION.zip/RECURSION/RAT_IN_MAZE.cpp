#include<iostream>
using namespace std;
void rat_in_maze(int array[4][4],int x,int y)
{
	
}
int main()
{
	int array[4][4] = {
						{1,1,0,0},
						{0,1,1,0},
						{1,0,1,0},
						{0,1,1,1},
						};
		rat_in_maze(array,0,0);
	return 0;
}

