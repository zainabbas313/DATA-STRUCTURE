#include<iostream>
using namespace std;
int sort_array(int arr[], int size)
{
	if(size == 0)
	{
		return 0;
	}
	int pos = sort_array(arr,size-1);
	if(arr[size]>arr[pos])
	{
		int hold = arr[size];
		arr[size] = arr[pos];
		arr[pos] = hold;
	}
//	return ;
	
}
int main()
{
	int size;
//	cout<<"ENTER THE SIZE OF AN ARRAY : ";
//	cin>>size;
//	int arr[size];
	int a[5] = {2,3,1,4,5};
	int *p = &a[0];
	sort_array(p,5);
		cout<<"SORTED ARRAY IS : ";
		for(int  i = 0; i < 5 ;i ++)
		{
			cout<<a[i]<<" ";
		}
		delete p;
	return 0;
}

