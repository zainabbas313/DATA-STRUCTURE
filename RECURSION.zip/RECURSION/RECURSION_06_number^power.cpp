#include<iostream>
using namespace std;
int returner(int x, int power)
{
	if(power == 0){
		return 0;
	}
	returner(x,power-1);
	return x * x;
}
int main()
{
	int num,pow;
	cout<<"ENTER NUMBER : ";
	cin>>num;
	cout<<"ENTERC POWER OF THE NUMBER : ";
	cin>>pow;
	cout<<"ANSWER IS : "<<returner(num,pow)<<endl;

	return 0;
}

