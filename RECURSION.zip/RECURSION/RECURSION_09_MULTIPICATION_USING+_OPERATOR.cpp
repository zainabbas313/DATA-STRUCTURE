#include<iostream>
using namespace std;
int multiply(int a,int b)
{
	if(b == 1)
	{
		return a;
	}
	return a + multiply(a,b-1);
}
int main()
{
	int x,y;
	cout<<"ENTER TWO POSITIVE NUMBERS : ";
	cin>>x>>y;
	int ans = multiply(x,y);
	cout<<"ANSWER IS : "<<ans<<endl;

	return 0;
}

