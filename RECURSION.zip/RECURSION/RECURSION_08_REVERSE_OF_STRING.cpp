#include<iostream>
#include<string>
using namespace std;
int fun(string x, int n)
{ 
	if(x.length() == n)
	{
		return n;
	}
	else
	{
		cout<<"zain"<<endl;
		return fun(x,n+1);
		cout<<"abbas"<<x[n];
	}
	
}
int main()
{
	string line;
	cout<<"ENTER A STRING : ";
//	getline(cin,line);
	cin>>line;
	fun(line,0);
	return 0;
}

