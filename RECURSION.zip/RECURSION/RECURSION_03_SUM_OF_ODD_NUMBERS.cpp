#include<iostream>
using namespace std;
int sum_of_odd(int x)
{
	int sum = 0;
	if(x == 1)
	{
		return 1;
	}
	sum = sum_of_odd(x - 2);
	return x + sum;
}
int main()
{
	int num;
	cout<<"ENTER THE NUMBER FROM WHICH THE SUM OF ODD NUMBERS WILL BE CALCULATED : ";
	cin>>num;
	if(num % 2 != 0)
		cout<<"THE SUM IS : "<<sum_of_odd(num)<<endl;
	else
		cout<<"THE SUM IS : "<<sum_of_odd(num-1)<<endl;

	return 0;
}

