#include<iostream>
using namespace std;
int fabonacci(int num)
{
	if(num == 0 || num == 1)
	{
		return num;
	}
	return fabonacci(num-1) + fabonacci(num-2);
}
int main()
{
	cout<<"ANSWER IS : "<<fabonacci(5);

	return 0;
}

